<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'auth.php';

// Oturum kontrolü
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';

// Form gönderildi mi kontrol et
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $amount = floatval($_POST['amount']);
        
        // Miktar kontrolü
        if ($amount <= 0) {
            throw new Exception('Geçerli bir miktar giriniz!');
        }
        
        if ($amount < 10) {
            throw new Exception('Minimum 10 TL yükleyebilirsiniz!');
        }
        
        if ($amount > 10000) {
            throw new Exception('Maksimum 10.000 TL yükleyebilirsiniz!');
        }

        // Dosya yükleme dizinini kontrol et ve oluştur
        $uploadDir = 'uploads/payment_proofs';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Dosya yükleme işlemi
        $file = $_FILES['payment_proof'];
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $newFileName = uniqid() . '.' . $extension;
        $uploadPath = $uploadDir . '/' . $newFileName;
        
        if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
            throw new Exception('Dosya yüklenirken bir hata oluştu!');
        }
        
        // Transaction başlat
        $db->beginTransaction();
        
        try {
            // Bekleyen bakiye işlemi oluştur
            $stmt = $db->prepare("
                INSERT INTO pending_balance_transactions 
                (user_id, amount, proof_file, status, created_at) 
                VALUES (?, ?, ?, 'pending', NOW())
            ");
            $stmt->execute([$_SESSION['user_id'], $amount, $newFileName]);
            
            // Aktivite logunu kaydet
            $stmt = $db->prepare("
                INSERT INTO activity_logs 
                (user_id, action, details) 
                VALUES (?, 'balance_request', ?)
            ");
            $stmt->execute([
                $_SESSION['user_id'], 
                $amount . ' TL bakiye yükleme talebi oluşturuldu'
            ]);
            
            $db->commit();
            $success = 'Bakiye yükleme talebiniz alındı. Admin onayından sonra bakiyeniz güncellenecektir.';
            
        } catch (Exception $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            // Yüklenen dosyayı sil
            if (file_exists($uploadPath)) {
                unlink($uploadPath);
            }
            throw $e;
        }
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Mevcut bakiyeyi al
$currentBalance = getUserBalance();

// Header'ı dahil et
$pageTitle = "Bakiye Ekle";
include 'templates/header.php';
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h2 class="mb-0">Bakiye Ekle</h2>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>
                    
                    <div class="current-balance mb-4">
                        <h4>Mevcut Bakiyeniz</h4>
                        <p class="balance-amount"><?php echo formatMoney($currentBalance); ?> TL</p>
                    </div>
                    
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="amount" class="form-label">Yüklenecek Miktar (TL)</label>
                            <input type="number" 
                                   class="form-control" 
                                   id="amount" 
                                   name="amount" 
                                   min="10" 
                                   max="10000" 
                                   step="1" 
                                   required>
                            <small class="form-text text-muted">
                                Minimum 10 TL, maksimum 10.000 TL yükleyebilirsiniz.
                            </small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="payment_proof" class="form-label">Ödeme Kanıtı</label>
                            <input type="file" 
                                   class="form-control" 
                                   id="payment_proof" 
                                   name="payment_proof" 
                                   accept=".jpg,.jpeg,.png,.gif,.pdf"
                                   required>
                            <small class="form-text text-muted">
                                JPG, PNG, GIF veya PDF formatında, maksimum 5MB boyutunda dosya yükleyebilirsiniz.
                            </small>
                        </div>
                        
                        <div class="quick-amounts mb-3">
                            <label class="form-label">Hızlı Seçim</label>
                            <div class="btn-group w-100">
                                <button type="button" class="btn btn-outline-primary" onclick="setAmount(50)">50 TL</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setAmount(100)">100 TL</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setAmount(200)">200 TL</button>
                                <button type="button" class="btn btn-outline-primary" onclick="setAmount(500)">500 TL</button>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Bakiye Yükle</button>
                            <a href="index.php" class="btn btn-secondary">İptal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Bekleyen İşlemler Bölümü -->
        <div class="col-md-12 mt-4">
            <div class="card">
                <div class="card-header">
                    <h3>İşlem Geçmişi</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tarih</th>
                                    <th>Miktar</th>
                                    <th>Durum</th>
                                    <th>Not</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stmt = $db->prepare("
                                    SELECT * FROM pending_balance_transactions 
                                    WHERE user_id = ? 
                                    ORDER BY created_at DESC 
                                    LIMIT 10
                                ");
                                $stmt->execute([$_SESSION['user_id']]);
                                $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($transactions as $tx):
                                    $statusClass = [
                                        'pending' => 'bg-warning',
                                        'approved' => 'bg-success',
                                        'rejected' => 'bg-danger'
                                    ][$tx['status']];
                                    
                                    $statusText = [
                                        'pending' => 'Bekliyor',
                                        'approved' => 'Onaylandı',
                                        'rejected' => 'Reddedildi'
                                    ][$tx['status']];
                                ?>
                                <tr>
                                    <td><?php echo formatTime($tx['created_at']); ?></td>
                                    <td><?php echo formatMoney($tx['amount']); ?> TL</td>
                                    <td><span class="badge <?php echo $statusClass; ?>"><?php echo $statusText; ?></span></td>
                                    <td>
                                        <?php 
                                        if ($tx['status'] == 'rejected' && $tx['admin_note']) {
                                            echo htmlspecialchars($tx['admin_note']);
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.current-balance {
    text-align: center;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 8px;
}

.balance-amount {
    font-size: 24px;
    font-weight: bold;
    color: #28a745;
    margin: 0;
}

.quick-amounts .btn-group {
    display: flex;
    gap: 5px;
}

.quick-amounts .btn {
    flex: 1;
}

.badge {
    padding: 5px 10px;
    border-radius: 4px;
    font-weight: normal;
}
</style>

<script>
function setAmount(value) {
    document.getElementById('amount').value = value;
}
</script>

<?php include 'templates/footer.php'; ?> 