<?php
// Önceki çıktıları temizle
if (ob_get_level()) ob_end_clean();

// Hata gösterimini kapat
error_reporting(0);
ini_set('display_errors', 0);

// Çıktı tamponlamasını başlat
ob_start();

// Hata ayıklama için
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/debug.log');
error_log("Config dosyası yüklendi");

// Hata raporlama
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Veritabanı bağlantı bilgileri
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sanal_ciftlik');

// Veritabanı bağlantısı
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}

// Sabit değerler
define('SITE_NAME', 'Sanal Çiftlik');
define('SITE_URL', 'http://localhost/sanal_ciftlik');

// Zaman dilimi ayarı
date_default_timezone_set('Europe/Istanbul');

// Oturum güvenliği
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1);

// Genel site ayarları
define('MAX_FEED_INTERVAL', 4); // Saat cinsinden maksimum besleme aralığı
define('HEALTH_DECREASE_RATE', 5); // Saat başına düşen sağlık puanı
define('MIN_SELLING_AGE', 30); // Gün cinsinden minimum satış yaşı

// Hayvan büyüme ve gelişim sabitleri
define('BASE_GROWTH_RATE', 0.1); // Temel büyüme oranı
define('HEALTH_MULTIPLIER', 1.2); // Sağlık çarpanı
define('FEEDING_MULTIPLIER', 1.5); // Beslenme çarpanı

// Fiyatlandırma sabitleri
define('BASE_PRICE_MULTIPLIER', 1.1); // Temel fiyat çarpanı
define('HEALTH_PRICE_EFFECT', 0.2); // Sağlık durumunun fiyata etkisi
define('WEIGHT_PRICE_EFFECT', 0.3); // Kilonun fiyata etkisi 