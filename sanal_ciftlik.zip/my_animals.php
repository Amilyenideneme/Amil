<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'auth.php';

// Oturum kontrolü
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Header'ı dahil et
$pageTitle = "Hayvanlarım";
include 'templates/header.php';

// Kullanıcının hayvanlarını getir
$stmt = $db->prepare("
    SELECT 
        ua.*,
        at.name as animal_type,
        at.selling_age,
        at.feeding_cost,
        at.growth_rate,
        TIMESTAMPDIFF(HOUR, ua.last_fed, NOW()) as hours_since_fed
    FROM user_animals ua 
    JOIN animal_types at ON ua.animal_type_id = at.id 
    WHERE ua.user_id = ?
    ORDER BY ua.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$animals = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Modal'ı dahil et -->
<?php include 'templates/animal_details_modal.php'; ?>

<div class="container">
    <div class="my-animals-container">
        <div class="section-header">
            <h2><i class="fas fa-paw"></i> Hayvanlarım</h2>
            <span class="animal-count"><?php echo count($animals); ?> Hayvan</span>
        </div>

        <?php if (empty($animals)): ?>
            <div class="empty-state">
                <i class="fas fa-seedling empty-icon"></i>
                <h3>Henüz Hiç Hayvanınız Yok</h3>
                <p>Çiftliğinizi büyütmek için hemen bir hayvan satın alın!</p>
                <a href="store.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-store"></i> Mağazaya Git
                </a>
            </div>
        <?php else: ?>
            <div class="animals-grid">
                <?php foreach ($animals as $animal): ?>
                    <div class="animal-card <?php echo $animal['health'] <= 20 ? 'low-health' : ''; ?>" 
                         id="animal-<?php echo $animal['id']; ?>">
                        <div class="animal-icon">
                            <i class="fas <?php echo getAnimalIcon($animal['animal_type']); ?>"></i>
                        </div>
                        <div class="animal-header">
                            <div class="animal-type">
                                <i class="fas <?php echo getAnimalIcon($animal['animal_type']); ?>"></i>
                                <h3><?php echo htmlspecialchars($animal['animal_type']); ?></h3>
                            </div>
                            <span class="animal-id">#<?php echo $animal['id']; ?></span>
                        </div>

                        <div class="animal-detail-button mb-3">
                            <button class="btn btn-info btn-sm w-100" data-bs-toggle="modal" data-bs-target="#animalModal" 
                                    onclick="showAnimalDetails(<?php echo $animal['id']; ?>)">
                                <i class="fas fa-info-circle"></i> Detaylı Bilgi
                            </button>
                        </div>

                        <div class="animal-stats">
                            <div class="stat-row">
                                <i class="fas fa-birthday-cake"></i>
                                <span>Yaş: <strong><?php echo number_format($animal['age'], 1); ?> gün</strong></span>
                            </div>

                            <div class="stat-row">
                                <i class="fas fa-heartbeat"></i>
                                <div class="progress">
                                    <div class="progress-bar bg-<?php echo getHealthColor($animal['health']); ?>" 
                                         role="progressbar" 
                                         style="width: <?php echo $animal['health']; ?>%">
                                        Sağlık: %<?php echo $animal['health']; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="stat-row">
                                <i class="fas fa-battery-half"></i>
                                <div class="progress">
                                    <div class="progress-bar bg-<?php echo getEnergyColor($animal['energy']); ?>" 
                                         role="progressbar" 
                                         style="width: <?php echo $animal['energy']; ?>%">
                                        Enerji: %<?php echo $animal['energy']; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="stat-row">
                                <i class="fas fa-weight"></i>
                                <span>Kilo: <strong><?php echo number_format($animal['weight'], 1); ?> kg</strong></span>
                            </div>

                            <div class="stat-row">
                                <i class="fas fa-coins"></i>
                                <span>Değer: <strong><?php echo formatMoney($animal['price']); ?></strong></span>
                            </div>
                        </div>

                        <div class="feeding-controls">
                            <div class="feeding-timer mb-2" 
                                 data-last-fed="<?php echo $animal['last_fed']; ?>" 
                                 data-interval="<?php echo getSetting('feeding_interval', 60); ?>">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                                </div>
                                <small class="timer-text">Yükleniyor...</small>
                            </div>
                            
                            <button onclick="feedAnimal(<?php echo $animal['id']; ?>)" 
                                    class="btn btn-success btn-sm w-100 feed-button" 
                                    data-animal-id="<?php echo $animal['id']; ?>">
                                <i class="fas fa-utensils"></i> Besle
                                <span class="feed-cost">(<?php echo formatMoney($animal['feeding_cost']); ?>)</span>
                            </button>
                        </div>

                        <?php if ($animal['age'] >= $animal['selling_age']): ?>
                            <button onclick="sellAnimal(<?php echo $animal['id']; ?>)" class="btn btn-warning">
                                <i class="fas fa-coins"></i> Sat
                            </button>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Gerekli JavaScript dosyalarını ekleyin (footer'dan önce) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Modal ve event listener'ları başlat
document.addEventListener('DOMContentLoaded', function() {
    // Modal elementini al
    const modalElement = document.getElementById('animalModal');
    
    // Modal instance'ını oluştur
    const animalModal = new bootstrap.Modal(modalElement, {
        backdrop: 'static',
        keyboard: false
    });
    
    // Modal kapanma olayını dinle
    modalElement.addEventListener('hidden.bs.modal', function() {
        // Modal içeriğini temizle
        const modalContent = document.getElementById('animalDetailsContent');
        modalContent.innerHTML = `
            <div class="text-center">
                <div class="spinner-border" role="status">
                    <span class="visually-hidden">Yükleniyor...</span>
                </div>
            </div>
        `;
    });
});

// Besleme fonksiyonu
async function feedAnimal(animalId) {
    try {
        // Besleme isteği gönder
        const response = await fetch('actions/feed_animal.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `animal_id=${animalId}`
        });

        // Yanıtı kontrol et
        if (!response.ok) {
            throw new Error('Sunucu hatası');
        }

        const data = await response.json();

        if (data.success) {
            // Başarılı besleme
            alert('Hayvan başarıyla beslendi!');
            location.reload(); // Sayfayı yenile
        } else {
            // Hata durumu
            alert(data.message || 'Besleme işlemi başarısız oldu');
        }

    } catch (error) {
        console.error('Besleme hatası:', error);
        alert('Besleme işlemi sırasında bir hata oluştu');
    }
}

// Zamanlayıcı güncelleme fonksiyonu
function updateFeedingTimer(timer) {
    if (!timer) return;
    
    const lastFed = new Date(timer.dataset.lastFed);
    const intervalMinutes = parseInt(timer.dataset.interval);
    
    if (isNaN(lastFed.getTime()) || isNaN(intervalMinutes)) {
        console.error('Geçersiz değerler:', {lastFed, intervalMinutes});
        return;
    }

    const now = new Date();
    const diffInMinutes = Math.floor((now - lastFed) / (1000 * 60));
    const remainingMinutes = Math.max(0, intervalMinutes - diffInMinutes);
    
    const progress = Math.min(100, (diffInMinutes / intervalMinutes) * 100);
    
    const progressBar = timer.querySelector('.progress-bar');
    const timerText = timer.querySelector('.timer-text');
    const feedButton = timer.closest('.feeding-controls').querySelector('.feed-button');
    
    if (progressBar) progressBar.style.width = `${progress}%`;
    
    if (remainingMinutes <= 0) {
        if (timerText) timerText.textContent = 'Beslenebilir';
        if (progressBar) progressBar.classList.add('bg-success');
        if (feedButton) {
            feedButton.disabled = false;
            feedButton.classList.remove('disabled');
        }
    } else {
        if (timerText) timerText.textContent = `${remainingMinutes} dakika kaldı`;
        if (progressBar) progressBar.classList.remove('bg-success');
        if (feedButton) {
            feedButton.disabled = true;
            feedButton.classList.add('disabled');
        }
    }
}

// Sayfa yüklendiğinde ve her 1 dakikada bir zamanlayıcıları güncelle
document.addEventListener('DOMContentLoaded', function() {
    const updateAllTimers = () => {
        document.querySelectorAll('.feeding-timer').forEach(updateFeedingTimer);
    };
    
    updateAllTimers();
    setInterval(updateAllTimers, 60000); // Her 1 dakikada bir güncelle
});

// showAnimalDetails fonksiyonunu güncelleyelim (yaklaşık 336. satırdan sonra)
async function showAnimalDetails(animalId) {
    try {
        const modalContent = document.getElementById('animalDetailsContent');
        const modalElement = document.getElementById('animalModal');
        const modal = bootstrap.Modal.getInstance(modalElement) || new bootstrap.Modal(modalElement);
        
        // Modal'ı göster
        modal.show();
        
        const response = await fetch(`actions/get_animal_details.php?id=${animalId}`);
        const data = await response.json();
        
        if (data.success) {
            const details = data.animal;
            
            // Beslenme durumunu hesapla
            const lastFed = new Date(details.last_fed);
            const now = new Date();
            const diffInMinutes = Math.floor((now - lastFed) / (1000 * 60));
            const feedingInterval = 60; // Beslenme aralığı (dakika)
            const remainingMinutes = Math.max(0, feedingInterval - diffInMinutes);
            
            const feedingStatus = remainingMinutes <= 0 ? 'Beslenebilir' : `${remainingMinutes} dakika kaldı`;
            const statusClass = remainingMinutes <= 0 ? 'success' : 'warning';

            const content = `
                <div class="animal-details">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-item mb-3">
                                <i class="fas fa-paw"></i>
                                <strong>Tür:</strong> ${details.animal_type}
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-birthday-cake"></i>
                                <strong>Yaş:</strong> ${details.age} gün
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-weight"></i>
                                <strong>Kilo:</strong> ${details.weight} kg
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-coins"></i>
                                <strong>Değer:</strong> ${formatMoney(details.price)}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-item mb-3">
                                <i class="fas fa-heartbeat"></i>
                                <strong>Sağlık:</strong>
                                <div class="progress mt-1">
                                    <div class="progress-bar bg-${getHealthColor(details.health)}" 
                                         style="width: ${details.health}%">
                                        %${details.health}
                                    </div>
                                </div>
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-battery-half"></i>
                                <strong>Enerji:</strong>
                                <div class="progress mt-1">
                                    <div class="progress-bar bg-${getEnergyColor(details.energy)}" 
                                         style="width: ${details.energy}%">
                                        %${details.energy}
                                    </div>
                                </div>
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-utensils"></i>
                                <strong>Beslenme Durumu:</strong> 
                                <span class="badge bg-${statusClass}">
                                    ${feedingStatus}
                                </span>
                                ${remainingMinutes > 0 ? `
                                    <br>
                                    <small class="text-muted ms-4">
                                        Bir sonraki beslenme: ${remainingMinutes} dakika sonra
                                    </small>
                                ` : ''}
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-history"></i>
                                <strong>Son Beslenme:</strong> ${details.last_fed}
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-clock"></i>
                                <strong>Oluşturulma:</strong> ${details.created_at}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            modalContent.innerHTML = content;
        } else {
            throw new Error(data.message || 'Hayvan detayları alınamadı');
        }
    } catch (error) {
        console.error('Detay getirme hatası:', error);
        modalContent.innerHTML = `
            <div class="alert alert-danger">
                Hayvan detayları yüklenirken bir hata oluştu: ${error.message}
            </div>
        `;
    }
}

// Yardımcı fonksiyonları ekleyelim
function formatMoney(amount) {
    return new Intl.NumberFormat('tr-TR', {
        style: 'currency',
        currency: 'TRY'
    }).format(amount);
}

function getHealthColor(health) {
    if (health >= 80) return 'success';
    if (health >= 50) return 'warning';
    return 'danger';
}

function getEnergyColor(energy) {
    if (energy >= 80) return 'success';
    if (energy >= 50) return 'warning';
    return 'danger';
}
</script>

<style>
.detail-item {
    padding: 10px;
    border-radius: 8px;
    background: #f8f9fa;
    margin-bottom: 10px;
}

.detail-item i {
    width: 25px;
    color: #666;
}

.detail-item strong {
    margin-right: 8px;
}

.progress {
    height: 10px;
    margin-top: 8px;
}

.badge {
    padding: 5px 10px;
    font-weight: normal;
}

.animal-details .row {
    margin: 0 -10px;
}

.animal-details .col-md-6 {
    padding: 0 10px;
}

.feeding-controls {
    margin-top: 10px;
}

.feeding-timer {
    position: relative;
}

.feeding-timer .progress {
    height: 6px;
    border-radius: 3px;
}

.timer-text {
    font-size: 0.8rem;
    color: #666;
    margin-top: 2px;
    display: block;
    text-align: center;
}

.feed-button:not(.disabled) {
    cursor: pointer;
}

.feed-button.disabled {
    opacity: 0.7;
    cursor: not-allowed;
}

.feed-cost {
    font-size: 0.8rem;
    opacity: 0.8;
}
</style>

<!-- Sayfanın sonuna modal yapısını ekleyin (footer'dan önce) -->
<div class="modal fade" id="animalModal" tabindex="-1" aria-labelledby="animalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="animalModalLabel">Hayvan Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <div class="modal-body">
                <div id="animalDetailsContent">
                    <div class="text-center">
                        <div class="spinner-border" role="status">
                            <span class="visually-hidden">Yükleniyor...</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>

<?php include 'templates/footer.php'; ?>