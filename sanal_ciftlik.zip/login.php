<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

// Kullanıcı zaten giriş yapmışsa ana sayfaya yönlendir
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = cleanInput($_POST['username']);
    $password = $_POST['password'];
    
    try {
        $stmt = $db->prepare("SELECT id, username, password, is_banned, is_admin FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            if ($user['is_banned']) {
                $error = 'Hesabınız askıya alınmıştır.';
            } else {
                // Oturum başlat
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['is_admin'] = $user['is_admin'];
                
                // Son giriş zamanını güncelle
                $stmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                $stmt->execute([$user['id']]);
                
                // Aktivite logunu kaydet
                $stmt = $db->prepare("INSERT INTO activity_logs (user_id, action, details) VALUES (?, 'login', 'Kullanıcı giriş yaptı')");
                $stmt->execute([$user['id']]);
                
                header('Location: index.php');
                exit();
            }
        } else {
            $error = 'Geçersiz kullanıcı adı veya şifre!';
        }
    } catch (PDOException $e) {
        $error = 'Bir hata oluştu, lütfen tekrar deneyin.';
        error_log($e->getMessage());
    }
}
?>

<?php include 'templates/header.php'; ?>

<div class="container">
    <div class="auth-form">
        <h2>Giriş Yap</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="username">Kullanıcı Adı:</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="password">Şifre:</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Giriş Yap</button>
        </form>
        
        <div class="auth-links">
            <p>Hesabınız yok mu? <a href="register.php">Kayıt Ol</a></p>
        </div>
    </div>
</div>

<style>
.auth-form {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.auth-form h2 {
    text-align: center;
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 20px;
}

.auth-links {
    text-align: center;
    margin-top: 20px;
}
</style>

<?php include 'templates/footer.php'; ?> 