<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Oturum ve admin kontrolü
session_start();
checkAdmin();

// Filtreleme parametreleri
$filters = [
    'user_id' => $_GET['user_id'] ?? null,
    'type' => $_GET['type'] ?? null,
    'date_start' => $_GET['date_start'] ?? null,
    'date_end' => $_GET['date_end'] ?? null,
    'min_amount' => $_GET['min_amount'] ?? null,
    'max_amount' => $_GET['max_amount'] ?? null
];

// SQL sorgusu oluştur
$sql = "
    SELECT 
        bt.*,
        u.username,
        CASE 
            WHEN bt.type = 'deposit' THEN 'bg-success'
            WHEN bt.type = 'withdrawal' THEN 'bg-danger'
            WHEN bt.type = 'purchase' THEN 'bg-warning'
            WHEN bt.type = 'sale' THEN 'bg-info'
        END as badge_class
    FROM balance_transactions bt
    JOIN users u ON bt.user_id = u.id
    WHERE 1=1
";

$params = [];

// Filtreleri uygula
if ($filters['user_id']) {
    $sql .= " AND bt.user_id = ?";
    $params[] = $filters['user_id'];
}

if ($filters['type']) {
    $sql .= " AND bt.type = ?";
    $params[] = $filters['type'];
}

if ($filters['date_start']) {
    $sql .= " AND bt.created_at >= ?";
    $params[] = $filters['date_start'] . ' 00:00:00';
}

if ($filters['date_end']) {
    $sql .= " AND bt.created_at <= ?";
    $params[] = $filters['date_end'] . ' 23:59:59';
}

if ($filters['min_amount']) {
    $sql .= " AND bt.amount >= ?";
    $params[] = $filters['min_amount'];
}

if ($filters['max_amount']) {
    $sql .= " AND bt.amount <= ?";
    $params[] = $filters['max_amount'];
}

$sql .= " ORDER BY bt.created_at DESC LIMIT 100";

// Sorguyu çalıştır
$stmt = $db->prepare($sql);
$stmt->execute($params);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Kullanıcı listesini getir (filtre için)
$users = $db->query("SELECT id, username FROM users ORDER BY username")->fetchAll(PDO::FETCH_ASSOC);

// Header'ı dahil et
$pageTitle = "İşlem Geçmişi";
include '../templates/header.php';
?>

<div class="container">
    <div class="admin-header">
        <h1>İşlem Geçmişi</h1>
        <a href="index.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Admin Paneline Dön
        </a>
    </div>

    <!-- Filtreler -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Filtreler</h5>
        </div>
        <div class="card-body">
            <form method="get" class="row g-3">
                <div class="col-md-3">
                    <label>Kullanıcı</label>
                    <select name="user_id" class="form-select">
                        <option value="">Tümü</option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?php echo $user['id']; ?>" 
                                    <?php echo $filters['user_id'] == $user['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($user['username']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label>İşlem Tipi</label>
                    <select name="type" class="form-select">
                        <option value="">Tümü</option>
                        <option value="deposit" <?php echo $filters['type'] == 'deposit' ? 'selected' : ''; ?>>Yükleme</option>
                        <option value="withdrawal" <?php echo $filters['type'] == 'withdrawal' ? 'selected' : ''; ?>>Çekim</option>
                        <option value="purchase" <?php echo $filters['type'] == 'purchase' ? 'selected' : ''; ?>>Satın Alma</option>
                        <option value="sale" <?php echo $filters['type'] == 'sale' ? 'selected' : ''; ?>>Satış</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label>Başlangıç Tarihi</label>
                    <input type="date" name="date_start" class="form-control" value="<?php echo $filters['date_start']; ?>">
                </div>

                <div class="col-md-3">
                    <label>Bitiş Tarihi</label>
                    <input type="date" name="date_end" class="form-control" value="<?php echo $filters['date_end']; ?>">
                </div>

                <div class="col-md-3">
                    <label>Min. Tutar</label>
                    <input type="number" name="min_amount" class="form-control" value="<?php echo $filters['min_amount']; ?>">
                </div>

                <div class="col-md-3">
                    <label>Max. Tutar</label>
                    <input type="number" name="max_amount" class="form-control" value="<?php echo $filters['max_amount']; ?>">
                </div>

                <div class="col-12">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filtrele
                    </button>
                    <a href="transactions.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Filtreleri Temizle
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- İşlem Listesi -->
    <div class="card">
        <div class="card-body">
            <?php if (empty($transactions)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h4>İşlem Bulunamadı</h4>
                    <p class="text-muted">Seçilen filtrelere uygun işlem kaydı bulunmamaktadır.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Kullanıcı</th>
                                <th>Tip</th>
                                <th>Tutar</th>
                                <th>Açıklama</th>
                                <th>Tarih</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $tx): ?>
                                <tr>
                                    <td><?php echo $tx['id']; ?></td>
                                    <td><?php echo htmlspecialchars($tx['username']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $tx['badge_class']; ?>">
                                            <?php 
                                            echo match($tx['type']) {
                                                'deposit' => 'Yükleme',
                                                'withdrawal' => 'Çekim',
                                                'purchase' => 'Satın Alma',
                                                'sale' => 'Satış',
                                                default => $tx['type']
                                            };
                                            ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatMoney($tx['amount']); ?></td>
                                    <td><?php echo htmlspecialchars($tx['description']); ?></td>
                                    <td><?php echo date('d.m.Y H:i', strtotime($tx['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.badge {
    padding: 6px 12px;
    font-size: 0.9em;
}
</style>

<?php include '../templates/footer.php'; ?> 