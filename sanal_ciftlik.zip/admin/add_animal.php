<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Oturum ve admin kontrolü
session_start();
checkAdmin();

// Form gönderildi mi kontrol et
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Form verilerini al ve temizle
        $name = cleanInput($_POST['name']);
        $initialWeight = floatval($_POST['initial_weight']);
        $initialPrice = floatval($_POST['initial_price']);
        $growthRate = floatval($_POST['growth_rate']);
        $sellingAge = intval($_POST['selling_age']);
        $profitPercentage = floatval($_POST['profit_percentage']);
        $feedingCost = floatval($_POST['feeding_cost']);
        
        // Verileri doğrula
        if (empty($name)) {
            throw new Exception("Hayvan türü adı boş olamaz!");
        }
        
        if ($initialWeight <= 0 || $initialPrice <= 0 || $growthRate <= 0 || 
            $sellingAge <= 0 || $profitPercentage < 0 || $feedingCost <= 0) {
            throw new Exception("Geçersiz değerler girdiniz!");
        }
        
        // Hayvan türünü veritabanına ekle
        $stmt = $db->prepare("
            INSERT INTO animal_types 
            (name, initial_weight, initial_price, growth_rate, selling_age, 
             profit_percentage, feeding_cost, active, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW())
        ");
        
        $stmt->execute([
            $name, $initialWeight, $initialPrice, $growthRate,
            $sellingAge, $profitPercentage, $feedingCost
        ]);
        
        $_SESSION['success'] = "Yeni hayvan türü başarıyla eklendi!";
        header('Location: index.php');
        exit;
        
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
}

// Header'ı dahil et
$pageTitle = "Yeni Hayvan Türü Ekle";
include '../templates/header.php';
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2 class="mb-0">Yeni Hayvan Türü Ekle</h2>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="name" class="form-label">Hayvan Türü Adı</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="initial_weight" class="form-label">Başlangıç Kilosu (kg)</label>
                            <input type="number" step="0.1" class="form-control" id="initial_weight" 
                                   name="initial_weight" required min="0.1">
                        </div>
                        
                        <div class="mb-3">
                            <label for="initial_price" class="form-label">Başlangıç Fiyatı (TL)</label>
                            <input type="number" step="0.01" class="form-control" id="initial_price" 
                                   name="initial_price" required min="0.01">
                        </div>
                        
                        <div class="mb-3">
                            <label for="growth_rate" class="form-label">Günlük Büyüme Oranı (kg)</label>
                            <input type="number" step="0.01" class="form-control" id="growth_rate" 
                                   name="growth_rate" required min="0.01">
                        </div>
                        
                        <div class="mb-3">
                            <label for="selling_age" class="form-label">Satış Yaşı (gün)</label>
                            <input type="number" class="form-control" id="selling_age" 
                                   name="selling_age" required min="1">
                        </div>
                        
                        <div class="mb-3">
                            <label for="profit_percentage" class="form-label">Kâr Yüzdesi (%)</label>
                            <input type="number" step="0.1" class="form-control" id="profit_percentage" 
                                   name="profit_percentage" required min="0">
                        </div>
                        
                        <div class="mb-3">
                            <label for="feeding_cost" class="form-label">Besleme Maliyeti (TL)</label>
                            <input type="number" step="0.01" class="form-control" id="feeding_cost" 
                                   name="feeding_cost" required min="0.01">
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Hayvan Türü Ekle</button>
                            <a href="index.php" class="btn btn-secondary">İptal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?> 