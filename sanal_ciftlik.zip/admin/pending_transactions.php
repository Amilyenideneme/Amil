<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

session_start();
checkAdmin();

$pageTitle = "Bekleyen İşlemler";
include '../templates/header.php';

// Bekleyen işlemleri getir
$transactions = $db->query("
    SELECT 
        pbt.*,
        u.username
    FROM pending_balance_transactions pbt
    JOIN users u ON pbt.user_id = u.id
    WHERE pbt.status = 'pending'
    ORDER BY pbt.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container">
    <h1>Bekleyen Bakiye İşlemleri</h1>
    
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kullanıcı</th>
                    <th>Miktar</th>
                    <th>Kanıt</th>
                    <th>Tarih</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $tx): ?>
                    <tr>
                        <td><?php echo $tx['id']; ?></td>
                        <td><?php echo htmlspecialchars($tx['username']); ?></td>
                        <td><?php echo formatMoney($tx['amount']); ?> TL</td>
                        <td>
                            <a href="../uploads/payment_proofs/<?php echo $tx['proof_file']; ?>" 
                               target="_blank" class="btn btn-sm btn-info">
                                <i class="fas fa-eye"></i> Görüntüle
                            </a>
                        </td>
                        <td><?php echo date('d.m.Y H:i', strtotime($tx['created_at'])); ?></td>
                        <td>
                            <button onclick="approveTransaction(<?php echo $tx['id']; ?>)" 
                                    class="btn btn-sm btn-success">
                                <i class="fas fa-check"></i> Onayla
                            </button>
                            <button onclick="rejectTransaction(<?php echo $tx['id']; ?>)" 
                                    class="btn btn-sm btn-danger">
                                <i class="fas fa-times"></i> Reddet
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Reddetme Modalı -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">İşlemi Reddet</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="rejectReason" class="form-label">Red Sebebi</label>
                    <textarea class="form-control" id="rejectReason" rows="3" required></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <button type="button" class="btn btn-danger" onclick="confirmReject()">Reddet</button>
            </div>
        </div>
    </div>
</div>

<script>
let currentTxId = null;

function approveTransaction(id) {
    if (confirm('Bu işlemi onaylamak istediğinize emin misiniz?')) {
        fetch('actions/approve_transaction.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: id })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert(data.message || 'Bir hata oluştu');
            }
        });
    }
}

function rejectTransaction(id) {
    currentTxId = id;
    const modal = new bootstrap.Modal(document.getElementById('rejectModal'));
    modal.show();
}

function confirmReject() {
    const reason = document.getElementById('rejectReason').value.trim();
    
    if (!reason) {
        alert('Lütfen red sebebi belirtin!');
        return;
    }
    
    fetch('actions/reject_transaction.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            id: currentTxId,
            reason: reason
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert(data.message || 'Bir hata oluştu');
        }
    });
}
</script>

<?php include '../templates/footer.php'; ?> 