<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Oturum ve admin kontrolü
session_start();
checkAdmin();

// Header'ı dahil et
$pageTitle = "Admin Paneli";
include '../templates/header.php';

// İstatistikleri getir
$stats = [
    'total_users' => $db->query("SELECT COUNT(*) FROM users WHERE is_admin = 0")->fetchColumn(),
    'total_animals' => $db->query("SELECT COUNT(*) FROM user_animals")->fetchColumn(),
    'total_transactions' => $db->query("SELECT COUNT(*) FROM balance_transactions")->fetchColumn(),
    'total_balance' => $db->query("SELECT SUM(balance) FROM users")->fetchColumn(),
    'pending_transactions' => $db->query("SELECT COUNT(*) FROM pending_balance_transactions WHERE status = 'pending'")->fetchColumn()
];

// Son aktiviteleri getir
$activities = $db->query("
    SELECT 
        al.*, 
        u.username,
        CASE 
            WHEN al.action = 'balance_request' THEN 'bg-warning text-dark'
            WHEN al.action = 'balance_approved' THEN 'bg-success text-white'
            WHEN al.action = 'balance_rejected' THEN 'bg-danger text-white'
            ELSE ''
        END as badge_class
    FROM activity_logs al 
    JOIN users u ON al.user_id = u.id 
    ORDER BY al.created_at DESC 
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container">
    <div class="admin-header">
        <h1>Admin Paneli</h1>
        <div class="admin-actions">
            <a href="manage_users.php" class="btn btn-primary">
                <i class="fas fa-users"></i> Kullanıcıları Yönet
            </a>
            <a href="add_animal.php" class="btn btn-success">
                <i class="fas fa-paw"></i> Hayvanları Yönet
            </a>
            <a href="pending_transactions.php" class="btn btn-warning">
                <i class="fas fa-clock"></i> Bekleyen İşlemler
                <?php if ($stats['pending_transactions'] > 0): ?>
                    <span class="badge bg-danger"><?php echo $stats['pending_transactions']; ?></span>
                <?php endif; ?>
            </a>
            <a href="transactions.php" class="btn btn-info">
                <i class="fas fa-exchange-alt"></i> İşlem Geçmişi
            </a>
            <a href="settings.php" class="btn btn-secondary">
                <i class="fas fa-cog"></i> Ayarlar
            </a>
        </div>
    </div>

    <!-- İstatistikler -->
    <div class="stats-grid">
        <div class="stat-card">
            <i class="fas fa-users"></i>
            <div class="stat-info">
                <h3>Toplam Kullanıcı</h3>
                <span><?php echo number_format($stats['total_users']); ?></span>
            </div>
        </div>

        <div class="stat-card">
            <i class="fas fa-paw"></i>
            <div class="stat-info">
                <h3>Toplam Hayvan</h3>
                <span><?php echo number_format($stats['total_animals']); ?></span>
            </div>
        </div>

        <div class="stat-card">
            <i class="fas fa-exchange-alt"></i>
            <div class="stat-info">
                <h3>Toplam İşlem</h3>
                <span><?php echo number_format($stats['total_transactions']); ?></span>
            </div>
        </div>

        <div class="stat-card">
            <i class="fas fa-coins"></i>
            <div class="stat-info">
                <h3>Toplam Bakiye</h3>
                <span><?php echo formatMoney($stats['total_balance']); ?></span>
            </div>
        </div>

        <div class="stat-card">
            <i class="fas fa-clock"></i>
            <div class="stat-info">
                <h3>Bekleyen İşlemler</h3>
                <span><?php echo number_format($stats['pending_transactions']); ?></span>
            </div>
        </div>
    </div>

    <!-- Son Aktiviteler -->
    <div class="activities-section">
        <h2>Son Aktiviteler</h2>
        <div class="activities-list">
            <?php foreach ($activities as $activity): ?>
                <div class="activity-item">
                    <div class="activity-icon">
                        <?php if (strpos($activity['action'], 'balance_') === 0): ?>
                            <i class="fas fa-coins"></i>
                        <?php else: ?>
                            <i class="fas fa-history"></i>
                        <?php endif; ?>
                    </div>
                    <div class="activity-details">
                        <span class="activity-user"><?php echo htmlspecialchars($activity['username']); ?></span>
                        <span class="activity-action <?php echo $activity['badge_class']; ?> badge">
                            <?php echo htmlspecialchars($activity['action']); ?>
                        </span>
                        <span class="activity-details"><?php echo htmlspecialchars($activity['details']); ?></span>
                        <span class="activity-time"><?php echo date('d.m.Y H:i', strtotime($activity['created_at'])); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<style>
.admin-header {
    margin-bottom: 30px;
}

.admin-actions {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    flex-wrap: wrap;
}

.admin-actions .btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 20px;
}

.admin-actions .btn i {
    font-size: 1.1em;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    display: flex;
    align-items: center;
    gap: 15px;
}

.stat-card i {
    font-size: 2em;
    color: #007bff;
}

.stat-info h3 {
    margin: 0;
    font-size: 0.9em;
    color: #666;
}

.stat-info span {
    font-size: 1.5em;
    font-weight: bold;
    color: #333;
}

.activities-section {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.activity-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.activity-icon i {
    color: #007bff;
}

.activity-details {
    display: flex;
    flex-direction: column;
}

.activity-user {
    font-weight: bold;
}

.activity-time {
    font-size: 0.8em;
    color: #666;
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
}

.admin-actions .badge {
    margin-left: 5px;
    font-size: 0.8em;
    padding: 4px 8px;
    border-radius: 10px;
}

.activity-action.badge {
    display: inline-block;
    padding: 4px 8px;
    margin: 2px 0;
    border-radius: 4px;
    font-size: 0.8em;
}

.activity-details {
    margin: 2px 0;
    font-size: 0.9em;
    color: #666;
}

/* Bekleyen işlemler için özel stil */
.stat-card:last-child i {
    color: #ffc107;
}
</style>

<?php include '../templates/footer.php'; ?> 