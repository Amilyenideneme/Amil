<?php
require_once '../../config.php';
require_once '../../functions.php';
require_once '../../auth.php';

header('Content-Type: application/json');

session_start();
checkAdmin();

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $txId = intval($input['id']);
    $reason = trim($input['reason']);
    
    if (empty($reason)) {
        throw new Exception('Red sebebi belirtilmelidir!');
    }
    
    $db->beginTransaction();
    
    // İşlem bilgilerini al
    $stmt = $db->prepare("
        SELECT * FROM pending_balance_transactions 
        WHERE id = ? AND status = 'pending'
    ");
    $stmt->execute([$txId]);
    $tx = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$tx) {
        throw new Exception('İşlem bulunamadı veya zaten işlenmiş!');
    }
    
    // İşlem durumunu güncelle
    $stmt = $db->prepare("
        UPDATE pending_balance_transactions 
        SET status = 'rejected',
            admin_note = ?,
            updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->execute([$reason, $txId]);
    
    // Aktivite logu ekle
    $stmt = $db->prepare("
        INSERT INTO activity_logs 
        (user_id, action, details) 
        VALUES (?, 'balance_rejected', ?)
    ");
    $stmt->execute([
        $tx['user_id'],
        $tx['amount'] . ' TL bakiye yükleme talebi reddedildi. Sebep: ' . $reason
    ]);
    
    // Kullanıcıya bildirim gönder
    $stmt = $db->prepare("
        INSERT INTO notifications 
        (user_id, title, message, type) 
        VALUES (?, ?, ?, 'danger')
    ");
    $stmt->execute([
        $tx['user_id'],
        'Bakiye Yükleme Reddedildi',
        $tx['amount'] . ' TL tutarındaki bakiye yükleme talebiniz reddedilmiştir. Sebep: ' . $reason
    ]);
    
    $db->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'İşlem başarıyla reddedildi!'
    ]);
    
} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 