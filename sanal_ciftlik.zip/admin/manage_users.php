<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Oturum ve admin kontrolü
session_start();
checkAdmin();

// Kullanıcı işlemleri
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'update_balance':
                    $userId = intval($_POST['user_id']);
                    $amount = floatval($_POST['amount']);
                    
                    $stmt = $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
                    $stmt->execute([$amount, $userId]);
                    
                    $_SESSION['success'] = "Bakiye başarıyla güncellendi!";
                    break;
                    
                case 'ban_user':
                    $userId = intval($_POST['user_id']);
                    
                    $stmt = $db->prepare("UPDATE users SET is_banned = 1 WHERE id = ? AND is_admin = 0");
                    $stmt->execute([$userId]);
                    
                    $_SESSION['success'] = "Kullanıcı başarıyla yasaklandı!";
                    break;
                    
                case 'unban_user':
                    $userId = intval($_POST['user_id']);
                    
                    $stmt = $db->prepare("UPDATE users SET is_banned = 0 WHERE id = ?");
                    $stmt->execute([$userId]);
                    
                    $_SESSION['success'] = "Kullanıcının yasağı kaldırıldı!";
                    break;
            }
        }
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    
    header('Location: manage_users.php');
    exit;
}

// Kullanıcıları listele
$stmt = $db->prepare("
    SELECT 
        u.*,
        COUNT(ua.id) as animal_count,
        COALESCE(SUM(ua.price), 0) as total_animal_value
    FROM users u
    LEFT JOIN user_animals ua ON u.id = ua.user_id
    WHERE u.is_admin = 0
    GROUP BY u.id
    ORDER BY u.created_at DESC
");
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Header'ı dahil et
$pageTitle = "Kullanıcı Yönetimi";
include '../templates/header.php';
?>

<div class="container">
    <div class="admin-users">
        <h1 class="mb-4">Kullanıcı Yönetimi</h1>
        
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kullanıcı Adı</th>
                        <th>E-posta</th>
                        <th>Bakiye</th>
                        <th>Hayvan Sayısı</th>
                        <th>Toplam Değer</th>
                        <th>Durum</th>
                        <th>Kayıt Tarihi</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['id']; ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo formatMoney($user['balance']); ?></td>
                            <td><?php echo $user['animal_count']; ?></td>
                            <td><?php echo formatMoney($user['total_animal_value']); ?></td>
                            <td>
                                <?php if ($user['is_banned']): ?>
                                    <span class="badge bg-danger">Yasaklı</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo formatTime($user['created_at']); ?></td>
                            <td>
                                <!-- Bakiye Güncelleme -->
                                <button type="button" class="btn btn-sm btn-primary" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#balanceModal<?php echo $user['id']; ?>">
                                    <i class="fas fa-coins"></i>
                                </button>
                                
                                <!-- Yasaklama/Yasak Kaldırma -->
                                <?php if ($user['is_banned']): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="unban_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-success" 
                                                onclick="return confirm('Kullanıcının yasağını kaldırmak istediğinize emin misiniz?')">
                                            <i class="fas fa-unlock"></i>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="ban_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" 
                                                onclick="return confirm('Kullanıcıyı yasaklamak istediğinize emin misiniz?')">
                                            <i class="fas fa-ban"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <!-- Bakiye Güncelleme Modal -->
                        <div class="modal fade" id="balanceModal<?php echo $user['id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Bakiye Güncelle - <?php echo htmlspecialchars($user['username']); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form method="POST">
                                        <div class="modal-body">
                                            <input type="hidden" name="action" value="update_balance">
                                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                            <div class="mb-3">
                                                <label class="form-label">Miktar (TL)</label>
                                                <input type="number" step="0.01" class="form-control" name="amount" required>
                                                <small class="text-muted">Eksi (-) değer girerek bakiye düşürebilirsiniz.</small>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                                            <button type="submit" class="btn btn-primary">Güncelle</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../templates/footer.php'; ?> 