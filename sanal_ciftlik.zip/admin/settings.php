<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

// Oturum ve admin kontrolü
session_start();
checkAdmin();

$success = '';
$error = '';

// Ayarları kaydet
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db->beginTransaction();

        // Site ayarları
        $stmt = $db->prepare("
            UPDATE settings SET 
            value = CASE setting_key
                WHEN 'site_name' THEN ?
                WHEN 'site_description' THEN ?
                WHEN 'maintenance_mode' THEN ?
                WHEN 'min_deposit' THEN ?
                WHEN 'max_deposit' THEN ?
                WHEN 'min_withdrawal' THEN ?
                WHEN 'max_withdrawal' THEN ?
                WHEN 'daily_bonus' THEN ?
                WHEN 'referral_bonus' THEN ?
                WHEN 'referral_bonus_percentage' THEN ?
            END
            WHERE setting_key IN (
                'site_name', 'site_description', 'maintenance_mode',
                'min_deposit', 'max_deposit', 'min_withdrawal',
                'max_withdrawal', 'daily_bonus', 'referral_bonus',
                'referral_bonus_percentage'
            )
        ");

        $stmt->execute([
            $_POST['site_name'],
            $_POST['site_description'],
            isset($_POST['maintenance_mode']) ? 1 : 0,
            floatval($_POST['min_deposit']),
            floatval($_POST['max_deposit']),
            floatval($_POST['min_withdrawal']),
            floatval($_POST['max_withdrawal']),
            floatval($_POST['daily_bonus']),
            floatval($_POST['referral_bonus']),
            floatval($_POST['referral_bonus_percentage'])
        ]);

        // Beslenme ayarları
        $stmt = $db->prepare("
            UPDATE settings SET
            value = ?
            WHERE setting_key = 'feeding_interval'
        ");

        $stmt->execute([
            floatval($_POST['feeding_interval'])
        ]);

        // Enerji düşüş hızı ayarları
        $stmt = $db->prepare("
            UPDATE settings SET
            value = ?
            WHERE setting_key = 'energy_decay_rate'
        ");

        $stmt->execute([
            floatval($_POST['energy_decay_rate'])
        ]);

        // Hayvan ayarları
        $stmt = $db->prepare("
            UPDATE animal_types SET
            growth_rate = ?,
            profit_percentage = ?,
            feeding_cost = ?,
            active = ?
            WHERE id = ?
        ");

        foreach ($_POST['animals'] as $animalId => $animal) {
            $stmt->execute([
                floatval($animal['growth_rate']),
                floatval($animal['profit_percentage']),
                floatval($animal['feeding_cost']),
                isset($animal['active']) ? 1 : 0,
                $animalId
            ]);
        }

        $db->commit();
        $success = 'Ayarlar başarıyla güncellendi!';
        
    } catch (Exception $e) {
        $db->rollBack();
        $error = 'Ayarlar güncellenirken bir hata oluştu: ' . $e->getMessage();
    }
}

// Mevcut ayarları getir
$settings = [];
$stmt = $db->query("SELECT * FROM settings");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings[$row['setting_key']] = $row['value'];
}

// Hayvan türlerini getir
$stmt = $db->query("SELECT * FROM animal_types ORDER BY initial_price ASC");
$animalTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Header'ı dahil et
$pageTitle = "Site Ayarları";
include '../templates/header.php';
?>

<div class="container">
    <div class="admin-header">
        <h1>Site Ayarları</h1>
        <a href="index.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Admin Paneline Dön
        </a>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <form method="post" class="settings-form">
        <!-- Genel Ayarlar -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Genel Ayarlar</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Site Adı</label>
                        <input type="text" name="site_name" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label>Site Açıklaması</label>
                        <input type="text" name="site_description" class="form-control" 
                               value="<?php echo htmlspecialchars($settings['site_description'] ?? ''); ?>">
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="maintenance_mode" class="form-check-input" 
                                   id="maintenance_mode" <?php echo ($settings['maintenance_mode'] ?? 0) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="maintenance_mode">Bakım Modu</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Para Ayarları -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Para Ayarları</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label>Min. Yükleme</label>
                        <input type="number" name="min_deposit" class="form-control" 
                               value="<?php echo $settings['min_deposit'] ?? 10; ?>" required>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <label>Max. Yükleme</label>
                        <input type="number" name="max_deposit" class="form-control" 
                               value="<?php echo $settings['max_deposit'] ?? 10000; ?>" required>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <label>Min. Çekim</label>
                        <input type="number" name="min_withdrawal" class="form-control" 
                               value="<?php echo $settings['min_withdrawal'] ?? 100; ?>" required>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <label>Max. Çekim</label>
                        <input type="number" name="max_withdrawal" class="form-control" 
                               value="<?php echo $settings['max_withdrawal'] ?? 5000; ?>" required>
                    </div>
                </div>
            </div>
        </div>

        <!-- Beslenme ayarları -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Beslenme Ayarları</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Beslenme Aralığı (dakika)</label>
                        <input type="number" name="feeding_interval" class="form-control" 
                               value="<?php echo $settings['feeding_interval'] ?? 60; ?>" required>
                        <small class="text-muted">İki beslenme arası geçmesi gereken süre</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>Enerji Düşüş Hızı (dakika)</label>
                        <input type="number" name="energy_decay_rate" class="form-control" 
                               value="<?php echo $settings['energy_decay_rate'] ?? 1; ?>" required>
                        <small class="text-muted">Her dakikada düşecek enerji yüzdesi</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bonus Ayarları -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Bonus Ayarları</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label>Günlük Bonus (TL)</label>
                        <input type="number" name="daily_bonus" class="form-control" 
                               value="<?php echo $settings['daily_bonus'] ?? 5; ?>" required>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label>Referans Bonusu (%)</label>
                        <input type="number" name="referral_bonus" class="form-control" 
                               value="<?php echo $settings['referral_bonus'] ?? 10; ?>" required>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hayvan Ayarları -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Hayvan Ayarları</h5>
            </div>
            <div class="card-body">
                <?php foreach ($animalTypes as $animal): ?>
                    <div class="animal-settings mb-4">
                        <h6><?php echo htmlspecialchars($animal['name']); ?></h6>
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label>Büyüme Hızı (%/gün)</label>
                                <input type="number" step="0.01" 
                                       name="animals[<?php echo $animal['id']; ?>][growth_rate]" 
                                       class="form-control" 
                                       value="<?php echo $animal['growth_rate']; ?>" required>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label>Kâr Yüzdesi (%)</label>
                                <input type="number" step="0.01" 
                                       name="animals[<?php echo $animal['id']; ?>][profit_percentage]" 
                                       class="form-control" 
                                       value="<?php echo $animal['profit_percentage']; ?>" required>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label>Besleme Maliyeti (TL)</label>
                                <input type="number" step="0.01" 
                                       name="animals[<?php echo $animal['id']; ?>][feeding_cost]" 
                                       class="form-control" 
                                       value="<?php echo $animal['feeding_cost']; ?>" required>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <div class="form-check mt-4">
                                    <input type="checkbox" 
                                           name="animals[<?php echo $animal['id']; ?>][active]" 
                                           class="form-check-input" 
                                           id="animal_active_<?php echo $animal['id']; ?>"
                                           <?php echo $animal['active'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" 
                                           for="animal_active_<?php echo $animal['id']; ?>">Aktif</label>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Ayarları Kaydet
            </button>
        </div>
    </form>
</div>

<style>
.admin-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.settings-form .card {
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.settings-form .card-header {
    background-color: #f8f9fa;
}

.form-actions {
    margin-top: 20px;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 8px;
    text-align: center;
}

.animal-settings {
    padding: 15px;
    border: 1px solid #dee2e6;
    border-radius: 8px;
}

.animal-settings h6 {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}
</style>

<?php include '../templates/footer.php'; ?>
