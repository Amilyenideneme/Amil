<?php
if (count(get_included_files()) == 1) {
    die('Bu dosyaya doğrudan erişim yasaktır.');
}

/**
 * Oturum Yönetimi Fonksiyonları
 */

// Kullanıcı girişi
function userLogin($username, $password) {
    global $db;
    
    try {
        // Kullanıcıyı kontrol et
        $stmt = $db->prepare("SELECT id, username, password FROM users WHERE username = ?");
        $stmt->execute([cleanInput($username)]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user || !password_verify($password, $user['password'])) {
            throw new Exception("Geçersiz kullanıcı adı veya şifre!");
        }
        
        // Oturum başlat
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['login_time'] = time();
        
        // Son giriş zamanını güncelle
        $stmt = $db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        return true;
        
    } catch (Exception $e) {
        throw $e;
    }
}

// Kullanıcı kaydı
function userRegister($username, $password, $email) {
    global $db;
    
    try {
        // Kullanıcı adı kontrolü
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([cleanInput($username)]);
        if ($stmt->fetch()) {
            throw new Exception("Bu kullanıcı adı zaten kullanılıyor!");
        }
        
        // Email kontrolü
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([cleanInput($email)]);
        if ($stmt->fetch()) {
            throw new Exception("Bu email adresi zaten kullanılıyor!");
        }
        
        // Şifreyi hashle
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Yeni kullanıcı ekle
        $stmt = $db->prepare("
            INSERT INTO users (username, password, email, balance, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            cleanInput($username),
            $hashedPassword,
            cleanInput($email),
            1000 // Başlangıç bakiyesi
        ]);
        
        return true;
        
    } catch (Exception $e) {
        throw $e;
    }
}

// Kullanıcı çıkışı
function userLogout() {
    // Oturum değişkenlerini temizle
    $_SESSION = array();
    
    // Oturum çerezini sil
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Oturumu sonlandır
    session_destroy();
}

/**
 * Güvenlik Fonksiyonları
 */

// Oturum kontrolü
function checkAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
    
    // Oturum süresini kontrol et (2 saat)
    if (time() - $_SESSION['login_time'] > 7200) {
        userLogout();
        header('Location: login.php?expired=1');
        exit;
    }
}

// Admin kontrolü
function checkAdmin() {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
        header('Location: ../index.php');
        exit();
    }
}

// Kullanıcının admin olup olmadığını kontrol eden fonksiyon
function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

// Şifre değiştirme
function changePassword($userId, $currentPassword, $newPassword) {
    global $db;
    
    try {
        // Mevcut şifreyi kontrol et
        $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $currentHash = $stmt->fetchColumn();
        
        if (!password_verify($currentPassword, $currentHash)) {
            throw new Exception("Mevcut şifre yanlış!");
        }
        
        // Yeni şifreyi hashle ve güncelle
        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$newHash, $userId]);
        
        return true;
        
    } catch (Exception $e) {
        throw $e;
    }
}

// Şifre sıfırlama
function resetPassword($email) {
    global $db;
    
    try {
        // Kullanıcıyı kontrol et
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([cleanInput($email)]);
        $userId = $stmt->fetchColumn();
        
        if (!$userId) {
            throw new Exception("Bu email adresi ile kayıtlı kullanıcı bulunamadı!");
        }
        
        // Sıfırlama tokeni oluştur
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Token'ı kaydet
        $stmt = $db->prepare("
            INSERT INTO password_resets (user_id, token, expires_at) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$userId, $token, $expires]);
        
        // Email gönder (bu kısmı kendi email gönderim sisteminize göre düzenleyin)
        $resetLink = SITE_URL . "/reset_password.php?token=" . $token;
        // sendResetEmail($email, $resetLink);
        
        return true;
        
    } catch (Exception $e) {
        throw $e;
    }
}

/**
 * Yardımcı Fonksiyonlar
 */

// Kullanıcı bilgilerini getir
function getUserInfo($userId) {
    global $db;
    
    $stmt = $db->prepare("
        SELECT id, username, email, balance, created_at, last_login 
        FROM users 
        WHERE id = ?
    ");
    $stmt->execute([$userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Kullanıcı bakiyesini güncelle
function updateUserBalance($userId, $amount) {
    global $db;
    
    try {
        $db->beginTransaction();
        
        $stmt = $db->prepare("
            UPDATE users 
            SET balance = balance + ? 
            WHERE id = ?
        ");
        $stmt->execute([$amount, $userId]);
        
        $db->commit();
        return true;
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
} 