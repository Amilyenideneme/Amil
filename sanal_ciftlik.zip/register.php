<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

// Kullanıcı zaten giriş yapmışsa ana sayfaya yönlendir
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Referans kodunu URL'den al ve session'a kaydet
if (isset($_GET['ref'])) {
    $_SESSION['referral_code'] = cleanInput($_GET['ref']);
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = cleanInput($_POST['username']);
    $email = cleanInput($_POST['email']);
    $password = $_POST['password'];
    // Session'dan veya form'dan referans kodunu al
    $referralCode = cleanInput($_POST['referral_code'] ?? $_SESSION['referral_code'] ?? '');
    
    try {
        // Şifre kontrolü
        if ($password !== $_POST['password_confirm']) {
            throw new Exception('Şifreler eşleşmiyor!');
        }
        
        if (strlen($password) < 6) {
            throw new Exception('Şifre en az 6 karakter olmalıdır!');
        }
        
        // Kullanıcı adı ve email kontrolü
        $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception('Bu kullanıcı adı veya email zaten kullanılıyor!');
        }
        
        // Referans kodunu kontrol et
        $referredBy = null;
        if ($referralCode !== '') {
            $stmt = $db->prepare("SELECT id FROM users WHERE referral_code = ?");
            $stmt->execute([$referralCode]);
            $referrer = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($referrer) {
                $referredBy = $referrer['id'];
            } else {
                throw new Exception('Geçersiz referans kodu!');
            }
        }
        
        // Yeni kullanıcıyı kaydet
        $stmt = $db->prepare("
            INSERT INTO users (username, email, password, referral_code, referred_by) 
            VALUES (?, ?, ?, SUBSTRING(MD5(RAND()) FROM 1 FOR 8), ?)
        ");
        
        $stmt->execute([
            $username,
            $email,
            password_hash($password, PASSWORD_DEFAULT),
            $referredBy
        ]);
        
        $success = 'Kayıt başarılı! Şimdi giriş yapabilirsiniz.';
        
        // Session'daki referans kodunu temizle
        unset($_SESSION['referral_code']);
        
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<?php include 'templates/header.php'; ?>

<div class="container">
    <div class="auth-form">
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <h2>Kayıt Ol</h2>
        <form method="post" id="registerForm">
            <div class="form-group">
                <label>Kullanıcı Adı</label>
                <input type="text" name="username" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>E-posta</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Şifre</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Şifre Tekrar</label>
                <input type="password" name="password_confirm" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label>Referans Kodu (İsteğe bağlı)</label>
                <input type="text" name="referral_code" class="form-control" 
                       value="<?php echo htmlspecialchars($_SESSION['referral_code'] ?? ''); ?>">
            </div>
            
            <button type="submit" class="btn btn-primary w-100">Kayıt Ol</button>
        </form>
    </div>
</div>

<style>
.auth-form {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.auth-form h2 {
    text-align: center;
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 20px;
}

.auth-links {
    text-align: center;
    margin-top: 20px;
}
</style>

<?php include 'templates/footer.php'; ?> 