<?php
if (!defined('DB_HOST')) die('Doğrudan erişim engellendi.');
?>

<div class="modal fade" id="animalDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas animal-icon"></i>
                    <span class="animal-name"></span>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <!-- Sol Kolon - Temel Bilgiler -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">Temel Bilgiler</div>
                            <div class="card-body">
                                <div class="detail-item">
                                    <i class="fas fa-hashtag"></i>
                                    <span>ID: </span>
                                    <strong class="animal-id"></strong>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-birthday-cake"></i>
                                    <span>Yaş: </span>
                                    <strong class="animal-age"></strong>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-clock"></i>
                                    <span>Satış Yaşına Kalan: </span>
                                    <strong class="animal-remaining-age"></strong>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-weight"></i>
                                    <span>Kilo: </span>
                                    <strong class="animal-weight"></strong>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-coins"></i>
                                    <span>Güncel Değer: </span>
                                    <strong class="animal-value"></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Sağ Kolon - Durum Bilgileri -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">Durum Bilgileri</div>
                            <div class="card-body">
                                <!-- Sağlık Durumu -->
                                <div class="status-item">
                                    <label>
                                        <i class="fas fa-heartbeat"></i>
                                        Sağlık Durumu
                                    </label>
                                    <div class="progress">
                                        <div class="progress-bar health-bar" role="progressbar"></div>
                                    </div>
                                </div>
                                
                                <!-- Enerji Seviyesi -->
                                <div class="status-item">
                                    <label>
                                        <i class="fas fa-bolt"></i>
                                        Enerji Seviyesi
                                    </label>
                                    <div class="progress">
                                        <div class="progress-bar energy-bar" role="progressbar"></div>
                                    </div>
                                </div>
                                
                                <!-- Beslenme Durumu -->
                                <div class="status-item">
                                    <label>
                                        <i class="fas fa-utensils"></i>
                                        Beslenme Durumu
                                    </label>
                                    <div class="progress">
                                        <div class="progress-bar feeding-bar" role="progressbar"></div>
                                    </div>
                                </div>
                                
                                <!-- Sonraki Beslenme -->
                                <div class="detail-item">
                                    <i class="fas fa-clock"></i>
                                    <span>Sonraki Beslenme: </span>
                                    <strong class="next-feeding"></strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Büyüme Grafiği -->
                <div class="card mt-3">
                    <div class="card-header">Büyüme Grafiği</div>
                    <div class="card-body">
                        <canvas id="growthChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 