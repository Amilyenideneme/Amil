        <footer class="footer mt-auto py-3 bg-light">
            <div class="container text-center">
                <span class="text-muted">
                    &copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. Tüm hakları saklıdır.
                </span>
            </div>
        </footer>
        
        <!-- Loading Spinner -->
        <div id="loading" class="loading-overlay d-none">
            <div class="loading-spinner"></div>
        </div>
        
        <!-- Custom JavaScript -->
        <script>
            // AJAX istekleri için loading spinner'ı göster/gizle
            document.addEventListener('DOMContentLoaded', function() {
                const loading = document.getElementById('loading');
                
                window.showLoading = function() {
                    loading.classList.remove('d-none');
                }
                
                window.hideLoading = function() {
                    loading.classList.add('d-none');
                }
            });
        </script>
    </body>
</html> 