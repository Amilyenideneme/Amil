<?php 
if (!defined('DB_HOST')) die('Doğrudan erişim engellendi.'); 

// Global değişkenleri tanımla
global $db;
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="<?php echo SITE_URL; ?>">
            <i class="fas fa-farm"></i> <?php echo SITE_NAME; ?>
        </a>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>">
                            <i class="fas fa-home"></i> Ana Sayfa
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>/my_animals.php">
                            <i class="fas fa-paw"></i> Hayvanlarım
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>/store.php">
                            <i class="fas fa-store"></i> Mağaza
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
            
            <ul class="navbar-nav">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <span class="nav-link user-balance">
                            <i class="fas fa-coins"></i> Bakiye: <?php echo formatMoney(getUserBalance()); ?>
                        </span>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['username'] ?? 'Kullanıcı'); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <a class="dropdown-item" href="<?php echo SITE_URL; ?>/profile.php">
                                    <i class="fas fa-user-cog"></i> Profil
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?php echo SITE_URL; ?>/add_balance.php">
                                    <i class="fas fa-plus-circle"></i> Bakiye Ekle
                                </a>
                            </li>
                            <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                                <li>
                                    <a class="dropdown-item" href="<?php echo SITE_URL; ?>/admin/">
                                        <i class="fas fa-tools"></i> Admin Paneli
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo SITE_URL; ?>/logout.php">
                                    <i class="fas fa-sign-out-alt"></i> Çıkış Yap
                                </a>
                            </li>
                        </ul>
                    </li>
                    <!-- Bildirimler Dropdown -->
                    <li class="nav-item dropdown">
                        <?php
                        $stmt = $db->prepare("
                            SELECT COUNT(*) FROM notifications 
                            WHERE user_id = ? AND is_read = 0
                        ");
                        $stmt->execute([$_SESSION['user_id']]);
                        $unreadCount = $stmt->fetchColumn();
                        ?>
                        <a class="nav-link dropdown-toggle" href="#" id="notificationsDropdown" 
                           role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bell"></i>
                            <?php if ($unreadCount > 0): ?>
                                <span class="badge bg-danger"><?php echo $unreadCount; ?></span>
                            <?php endif; ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end notification-dropdown" 
                             aria-labelledby="notificationsDropdown">
                            <?php
                            $stmt = $db->prepare("
                                SELECT * FROM notifications 
                                WHERE user_id = ? 
                                ORDER BY created_at DESC 
                                LIMIT 5
                            ");
                            $stmt->execute([$_SESSION['user_id']]);
                            $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            if (empty($notifications)): ?>
                                <div class="dropdown-item text-muted">Bildirim bulunmuyor</div>
                            <?php else: 
                                foreach ($notifications as $notif): ?>
                                    <div class="dropdown-item notification-item <?php echo !$notif['is_read'] ? 'unread' : ''; ?>"
                                         onclick="markAsRead(<?php echo $notif['id']; ?>)">
                                        <div class="notification-title">
                                            <i class="fas fa-circle text-<?php echo $notif['type']; ?> me-2"></i>
                                            <?php echo htmlspecialchars($notif['title']); ?>
                                        </div>
                                        <div class="notification-message">
                                            <?php echo htmlspecialchars($notif['message']); ?>
                                        </div>
                                        <small class="text-muted">
                                            <?php echo formatTime($notif['created_at']); ?>
                                        </small>
                                    </div>
                                <?php endforeach;
                            endif; ?>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-center" href="notifications.php">
                                Tüm Bildirimleri Gör
                            </a>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>/login.php">
                            <i class="fas fa-sign-in-alt"></i> Giriş Yap
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo SITE_URL; ?>/register.php">
                            <i class="fas fa-user-plus"></i> Kayıt Ol
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav> 