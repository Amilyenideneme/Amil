<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'auth.php';

// Oturum kontrolü
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Kullanıcı bakiyesini al
$userBalance = getUserBalance();

// Mevcut hayvan türlerini getir
$stmt = $db->prepare("
    SELECT * FROM animal_types 
    WHERE active = 1 
    ORDER BY initial_price ASC
");
$stmt->execute();
$animalTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Header'ı dahil et
$pageTitle = "Hayvan Mağazası";
include 'templates/header.php';
?>

<div class="container">
    <div class="store-header">
        <h1>Hayvan Mağazası</h1>
        <div class="user-balance">
            Bakiyeniz: <strong><?php echo formatMoney($userBalance); ?></strong>
        </div>
    </div>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php 
            echo $_SESSION['error'];
            unset($_SESSION['error']);
            ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php 
            echo $_SESSION['success'];
            unset($_SESSION['success']);
            ?>
        </div>
    <?php endif; ?>

    <div class="animals-grid">
        <?php foreach ($animalTypes as $animal): ?>
            <div class="animal-card">
                <div class="animal-image">
                    <img src="assets/images/animals/<?php echo strtolower($animal['name']); ?>.png" 
                         alt="<?php echo htmlspecialchars($animal['name']); ?>"
                         onerror="this.src='assets/images/animals/default.png'">
                </div>
                
                <div class="animal-info">
                    <h3><?php echo htmlspecialchars($animal['name']); ?></h3>
                    
                    <div class="animal-stats">
                        <div class="stat">
                            <i class="fas fa-weight"></i>
                            Başlangıç Kilosu: <?php echo number_format($animal['initial_weight'], 2); ?> kg
                        </div>
                        
                        <div class="stat">
                            <i class="fas fa-chart-line"></i>
                            Büyüme Hızı: <?php echo number_format($animal['growth_rate'] * 100, 1); ?>%/gün
                        </div>
                        
                        <div class="stat">
                            <i class="fas fa-calendar-alt"></i>
                            Satış Yaşı: <?php echo $animal['selling_age']; ?> gün
                        </div>
                        
                        <div class="stat">
                            <i class="fas fa-percentage"></i>
                            Kâr Potansiyeli: %<?php echo number_format($animal['profit_percentage'], 0); ?>
                        </div>
                        
                        <div class="stat">
                            <i class="fas fa-utensils"></i>
                            Besleme Maliyeti: <?php echo formatMoney($animal['feeding_cost']); ?>
                        </div>
                    </div>
                    
                    <div class="animal-price">
                        <span class="price-tag"><?php echo formatMoney($animal['initial_price']); ?></span>
                        <button class="btn btn-primary buy-animal-btn" 
                                data-animal-type-id="<?php echo $animal['id']; ?>"
                                <?php echo ($userBalance < $animal['initial_price']) ? 'disabled' : ''; ?>>
                            <i class="fas fa-shopping-cart"></i> Satın Al
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
.store-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
}

.user-balance {
    font-size: 1.2em;
    padding: 10px 20px;
    background: #f8f9fa;
    border-radius: 8px;
}

.animals-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    padding: 20px 0;
}

.animal-card {
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
    transition: transform 0.2s;
}

.animal-card:hover {
    transform: translateY(-5px);
}

.animal-image {
    height: 200px;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f8f9fa;
}

.animal-image img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
}

.animal-info {
    padding: 20px;
}

.animal-info h3 {
    margin: 0 0 15px 0;
    color: #333;
}

.animal-stats {
    margin-bottom: 20px;
}

.stat {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 8px;
    color: #666;
}

.stat i {
    width: 20px;
    color: #007bff;
}

.animal-price {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 15px;
    border-top: 1px solid #eee;
}

.price-tag {
    font-size: 1.2em;
    font-weight: bold;
    color: #28a745;
}

@media (max-width: 768px) {
    .store-header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
}
</style>

<script>
// Swal.fire kullanarak daha iyi bir kullanıcı deneyimi sağlayalım
async function buyAnimal(animalTypeId) {
    try {
        // Kullanıcıya onay sor
        const result = await Swal.fire({
            title: 'Onay',
            text: 'Bu hayvanı satın almak istediğinize emin misiniz?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Evet, Satın Al',
            cancelButtonText: 'İptal',
            reverseButtons: true
        });

        if (!result.isConfirmed) {
            return;
        }

        // Loading göster
        Swal.fire({
            title: 'İşlem yapılıyor...',
            text: 'Lütfen bekleyin',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // API isteği
        const response = await fetch('actions/buy_animal.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                animal_type_id: animalTypeId
            })
        });

        const data = await response.json();

        if (data.success) {
            await Swal.fire({
                title: 'Başarılı!',
                text: 'Hayvan başarıyla satın alındı!',
                icon: 'success',
                confirmButtonText: 'Tamam'
            });
            
            // Hayvanlarım sayfasına yönlendir
            window.location.href = 'my_animals.php';
        } else {
            throw new Error(data.message || 'Bir hata oluştu');
        }

    } catch (error) {
        console.error('Hata:', error);
        await Swal.fire({
            title: 'Hata!',
            text: error.message || 'Bir hata oluştu. Lütfen tekrar deneyin.',
            icon: 'error',
            confirmButtonText: 'Tamam'
        });
    }
}

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // Tüm satın alma butonlarına tıklama olayı ekle
    const buyButtons = document.querySelectorAll('.buy-animal-btn');
    
    buyButtons.forEach(button => {
        button.onclick = function(e) {
            e.preventDefault();
            const animalTypeId = this.getAttribute('data-animal-type-id');
            if (animalTypeId) {
                buyAnimal(animalTypeId);
            }
        };
    });
});
</script>

<!-- SweetAlert2 kütüphanesini ekleyin (header.php'ye de ekleyebilirsiniz) -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php include 'templates/footer.php'; ?> 