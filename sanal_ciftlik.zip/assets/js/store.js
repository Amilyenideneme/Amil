async function buyAnimal(animalTypeId) {
    try {
        const confirmation = await Swal.fire({
            title: 'Onay',
            text: 'Bu hayvanı satın almak istediğinize emin misiniz?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Evet, Satın Al',
            cancelButtonText: 'İptal',
            reverseButtons: true
        });

        if (!confirmation.isConfirmed) {
            return;
        }

        Swal.fire({
            title: 'İşlem Yapılıyor',
            text: 'Lütfen bekleyin...',
            allowOutsideClick: false,
            showConfirmButton: false,
            willOpen: () => {
                Swal.showLoading();
            }
        });

        const response = await fetch('actions/buy_animal.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({
                animal_type_id: animalTypeId
            })
        });

        const data = await response.json();

        await Swal.close();

        if (data.success) {
            await Swal.fire({
                title: 'Başarılı!',
                text: 'Hayvan başarıyla satın alındı!',
                icon: 'success',
                confirmButtonText: 'Tamam'
            });

            window.location.href = 'my_animals.php';
        } else {
            throw new Error(data.message || 'Bir hata oluştu');
        }

    } catch (error) {
        console.error('Satın alma hatası:', error);
        
        await Swal.fire({
            title: 'Hata!',
            text: error.message || 'Bir hata oluştu',
            icon: 'error',
            confirmButtonText: 'Tamam'
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.buy-animal-btn').forEach(button => {
        button.addEventListener('click', async (e) => {
            e.preventDefault();
            const animalTypeId = button.getAttribute('data-animal-type-id');
            if (animalTypeId) {
                await buyAnimal(animalTypeId);
            }
        });
    });

    function updateBalance(newBalance) {
        const balanceElement = document.querySelector('.balance');
        if (balanceElement) {
            balanceElement.textContent = formatMoney(newBalance);
        }
    }

    function formatMoney(amount) {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: 'TRY',
            minimumFractionDigits: 2
        }).format(amount);
    }
}); 