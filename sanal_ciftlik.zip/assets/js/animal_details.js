async function showAnimalDetails(animalId) {
    const modalContent = document.getElementById('animalDetailsContent');
    modalContent.innerHTML = `
        <div class="text-center">
            <div class="spinner-border" role="status">
                <span class="visually-hidden">Yükleniyor...</span>
            </div>
        </div>
    `;

    try {
        const response = await fetch(`actions/get_animal_details.php?id=${animalId}`);
        const data = await response.json();

        if (!data.success) {
            throw new Error(data.message || 'Bilinmeyen bir hata oluştu');
        }

        const details = data.animal;
        
        const content = `
            <div class="animal-details">
                <div class="row">
                    <div class="col-md-6">
                        <div class="detail-item mb-3">
                            <i class="fas fa-paw"></i> Tür: ${details.animal_type}
                        </div>
                        <div class="detail-item mb-3">
                            <i class="fas fa-weight"></i> Ağırlık: ${details.weight} kg
                        </div>
                        <div class="detail-item mb-3">
                            <i class="fas fa-coins"></i> Değer: ${formatMoney(details.price)}
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="detail-item mb-3">
                            <i class="fas fa-heartbeat"></i> Sağlık: ${details.health}%
                            <div class="progress">
                                <div class="progress-bar bg-${getHealthColor(details.health)}" 
                                     style="width: ${details.health}%"></div>
                            </div>
                        </div>
                        <div class="detail-item mb-3">
                            <i class="fas fa-battery-half"></i> Enerji: ${details.energy}%
                            <div class="progress">
                                <div class="progress-bar bg-${getEnergyColor(details.energy)}" 
                                     style="width: ${details.energy}%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        modalContent.innerHTML = content;

    } catch (error) {
        console.error('Error:', error);
        modalContent.innerHTML = `
            <div class="alert alert-danger">
                <h5>Bir Hata Oluştu</h5>
                <p>${error.message}</p>
            </div>
        `;
    }
}

function updateFeedingTimer(timer) {
    if (!timer) return;
    
    const lastFed = new Date(timer.dataset.lastFed);
    const intervalMinutes = parseInt(timer.dataset.interval);
    
    if (isNaN(lastFed.getTime()) || isNaN(intervalMinutes)) {
        console.error('Geçersiz değerler:', {lastFed, intervalMinutes});
        return;
    }

    const now = new Date();
    const diffInMinutes = Math.floor((now - lastFed) / (1000 * 60));
    const remainingMinutes = Math.max(0, intervalMinutes - diffInMinutes);
    
    const progress = Math.min(100, (diffInMinutes / intervalMinutes) * 100);
    
    const progressBar = timer.querySelector('.progress-bar');
    const timerText = timer.querySelector('.timer-text');
    const feedButton = timer.closest('.feeding-controls').querySelector('.feed-button');
    
    if (progressBar) {
        progressBar.style.width = `${progress}%`;
        progressBar.className = `progress-bar ${remainingMinutes <= 0 ? 'bg-success' : 'bg-warning'}`;
    }
    
    if (remainingMinutes <= 0) {
        if (timerText) timerText.textContent = 'Beslenebilir';
        if (feedButton) {
            feedButton.disabled = false;
            feedButton.classList.remove('disabled');
        }
    } else {
        if (timerText) timerText.textContent = `${remainingMinutes} dakika kaldı`;
        if (feedButton) {
            feedButton.disabled = true;
            feedButton.classList.add('disabled');
        }
    }
}

function formatMoney(amount) {
    return new Intl.NumberFormat('tr-TR', {
        style: 'currency',
        currency: 'TRY'
    }).format(amount);
}

function getHealthColor(health) {
    if (health >= 75) return 'success';
    if (health >= 50) return 'warning';
    if (health >= 25) return 'info';
    return 'danger';
}

function getEnergyColor(energy) {
    if (energy >= 75) return 'success';
    if (energy >= 50) return 'warning';
    if (energy >= 25) return 'primary';
    return 'danger';
}

async function feedAnimal(animalId) {
    try {
        // Form verisi oluştur
        const formData = new FormData();
        formData.append('animal_id', animalId);

        const response = await fetch('actions/feed_animal.php', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.message || 'Besleme işlemi başarısız oldu');
        }

        // Başarılı besleme durumunda
        const animalCard = document.querySelector(`[data-animal-id="${animalId}"]`).closest('.animal-card');
        if (animalCard) {
            const timer = animalCard.querySelector('.feeding-timer');
            if (timer) {
                timer.dataset.lastFed = new Date().toISOString();
                updateFeedingTimer(timer);
            }
        }

        showAlert('Hayvan başarıyla beslendi!', 'success');
        
        // Sayfayı yenile
        setTimeout(() => {
            location.reload();
        }, 1500);

    } catch (error) {
        console.error('Besleme hatası:', error);
        showAlert(error.message, 'danger');
    }
}

// Hayvan kartını güncelle
async function updateAnimalCard(animalId) {
    try {
        const response = await fetch(`actions/get_animal_details.php?id=${animalId}`);
        const data = await response.json();
        
        if (data.success) {
            const animal = data.animal;
            const card = document.querySelector(`[data-id="${animalId}"]`);
            
            if (card) {
                // Enerji barını güncelle
                const energyBar = card.querySelector('.progress-bar[role="progressbar"]');
                if (energyBar) {
                    energyBar.style.width = `${animal.energy}%`;
                    energyBar.textContent = `%${animal.energy}`;
                    energyBar.className = `progress-bar bg-${getEnergyColor(animal.energy)}`;
                }
                
                // Besleme butonunu güncelle
                const feedButton = card.querySelector('button[onclick^="feedAnimal"]');
                if (feedButton) {
                    feedButton.disabled = animal.energy >= 100;
                }
            }
        }
    } catch (error) {
        console.error('Güncelleme hatası:', error);
    }
}

// Yardımcı fonksiyonlar
function showSuccess(message) {
    const toast = document.createElement('div');
    toast.className = 'toast align-items-center text-white bg-success border-0';
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    document.body.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

// Modal kapandığında interval'leri temizle
const animalDetailsModal = document.getElementById('animalDetailsModal');
if (animalDetailsModal) {
    animalDetailsModal.addEventListener('hidden.bs.modal', function () {
        const timers = document.querySelectorAll('.feeding-timer');
        timers.forEach(timer => {
            if (timer.dataset.intervalId) {
                clearInterval(parseInt(timer.dataset.intervalId));
            }
        });
    });
}

function initializeTimers() {
    // Tüm beslenme sayaçlarını bul
    const timers = document.querySelectorAll('.feeding-timer');
    
    // Her sayaç için
    timers.forEach(timer => {
        // İlk güncelleme
        updateFeedingTimer(timer);
        
        // Var olan interval'i temizle
        if (timer.dataset.intervalId) {
            clearInterval(parseInt(timer.dataset.intervalId));
        }
        
        // Yeni interval oluştur ve ID'sini sakla
        const intervalId = setInterval(() => {
            updateFeedingTimer(timer);
        }, 1000);
        
        timer.dataset.intervalId = intervalId;
    });
}

// Sayfa yüklendiğinde timerleri başlat
document.addEventListener('DOMContentLoaded', function() {
    const updateAllTimers = () => {
        document.querySelectorAll('.feeding-timer').forEach(updateFeedingTimer);
    };
    
    updateAllTimers();
    setInterval(updateAllTimers, 60000); // Her 1 dakikada bir güncelle
});