// Global değişkenler
const API_URL = window.location.origin;
let loadingRequests = 0;

// Loading spinner yönetimi
function showLoading() {
    loadingRequests++;
    document.getElementById('loading-spinner').style.display = 'block';
}

function hideLoading() {
    loadingRequests--;
    if (loadingRequests <= 0) {
        document.getElementById('loading-spinner').style.display = 'none';
        loadingRequests = 0;
    }
}

// API istekleri için yardımcı fonksiyon
async function apiRequest(endpoint, method = 'GET', data = null) {
    showLoading();
    
    try {
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        };

        if (data) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(`${API_URL}/${endpoint}`, options);
        const result = await response.json();

        if (!result.success) {
            throw new Error(result.message || 'Bir hata oluştu');
        }

        return result;
    } catch (error) {
        showError(error.message);
        throw error;
    } finally {
        hideLoading();
    }
}

// Bildirim işaretleme fonksiyonu
async function markAsRead(notificationId) {
    try {
        await apiRequest('actions/mark_notification.php', 'POST', {
            id: notificationId
        });
        
        // Bildirim sayısını güncelle
        const badge = document.querySelector('#notificationsDropdown .badge');
        if (badge) {
            const currentCount = parseInt(badge.textContent) - 1;
            if (currentCount <= 0) {
                badge.remove();
            } else {
                badge.textContent = currentCount;
            }
        }
        
        // Okundu stilini uygula
        const notification = document.querySelector(`.notification-item[data-id="${notificationId}"]`);
        if (notification) {
            notification.classList.remove('unread');
        }
        
    } catch (error) {
        console.error('Bildirim işaretleme hatası:', error);
    }
}

// Hayvan işlemleri
async function buyAnimal(animalTypeId) {
    try {
        if (!confirm('Bu hayvanı satın almak istediğinize emin misiniz?')) {
            return;
        }

        const result = await apiRequest('actions/buy_animal.php', 'POST', {
            animal_type_id: animalTypeId
        });

        showSuccess('Hayvan başarıyla satın alındı!');
        setTimeout(() => location.reload(), 1500);

    } catch (error) {
        console.error('Hayvan satın alma hatası:', error);
    }
}

async function feedAnimal(animalId) {
    try {
        const response = await fetch('actions/feed_animal.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ animal_id: animalId })
        });

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.message || 'Besleme işlemi başarısız oldu');
        }

        // Başarılı besleme durumunda
        showAlert('Hayvan başarıyla beslendi!', 'success');
        
        // Hayvan kartını güncelle
        updateAnimalCard(animalId);

    } catch (error) {
        console.error('Besleme hatası:', error);
        showAlert(error.message, 'danger');
    }
}

async function sellAnimal(animalId) {
    try {
        if (!confirm('Hayvanı satmak istediğinize emin misiniz?')) {
            return;
        }

        const result = await apiRequest('actions/sell_animal.php', 'POST', {
            animal_id: animalId
        });

        showSuccess('Hayvan başarıyla satıldı!');
        setTimeout(() => location.reload(), 1500);

    } catch (error) {
        console.error('Satış hatası:', error);
    }
}

// Hayvan istatistiklerini güncelle
async function updateAnimalStats(animalId) {
    try {
        const response = await fetch(`actions/get_animal_stats.php?id=${animalId}`);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message);
        }
        
        const stats = data.stats;
        const card = document.querySelector(`.animal-card[data-id="${animalId}"]`);
        
        if (!card) return;
        
        // Sağlık ve enerji barlarını güncelle
        const healthBar = card.querySelector('.health-bar');
        const energyBar = card.querySelector('.energy-bar');
        
        if (healthBar) {
            healthBar.style.width = `${stats.health}%`;
            healthBar.className = `progress-bar bg-${getHealthColor(stats.health)}`;
            healthBar.textContent = `Sağlık: %${stats.health}`;
        }
        
        if (energyBar) {
            energyBar.style.width = `${stats.energy}%`;
            energyBar.className = `progress-bar bg-${getEnergyColor(stats.energy)}`;
            energyBar.textContent = `Enerji: %${stats.energy}`;
        }
        
        // Kilo ve değer bilgilerini güncelle
        const weightElement = card.querySelector('.weight-value');
        const priceElement = card.querySelector('.price-value');
        
        if (weightElement) {
            weightElement.textContent = `${stats.weight.toFixed(1)} kg`;
        }
        
        if (priceElement) {
            priceElement.textContent = formatMoney(stats.price);
        }
        
        // Beslenme durumunu güncelle
        const feedButton = card.querySelector('.feed-button');
        if (feedButton) {
            feedButton.disabled = !stats.can_feed;
        }
        
    } catch (error) {
        console.error('Hayvan istatistikleri güncellenirken hata:', error);
    }
}

// Bildirim gösterme fonksiyonları
function showSuccess(message) {
    showAlert(message, 'success');
}

function showError(message) {
    showAlert(message, 'danger');
}

function showWarning(message) {
    showAlert(message, 'warning');
}

function showInfo(message) {
    showAlert(message, 'info');
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.setAttribute('role', 'alert');
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    const container = document.querySelector('.notifications');
    container.appendChild(alertDiv);

    // 5 saniye sonra otomatik kapat
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Para formatı
function formatMoney(amount) {
    return new Intl.NumberFormat('tr-TR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

// Form doğrulama
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return true;

    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('is-invalid');
            isValid = false;
        } else {
            input.classList.remove('is-invalid');
        }
    });

    return isValid;
}

// Yardımcı fonksiyonlar
function getHealthColor(health) {
    if (health >= 75) return 'success';
    if (health >= 50) return 'warning';
    if (health >= 25) return 'info';
    return 'danger';
}

function getEnergyColor(energy) {
    if (energy >= 75) return 'success';
    if (energy >= 50) return 'warning';
    if (energy >= 25) return 'primary';
    return 'danger';
}

function formatNumber(number, decimals = 0) {
    return Number(number).toFixed(decimals);
}

// Hayvan kartını güncelle
async function updateAnimalCard(animalId) {
    try {
        const response = await fetch(`actions/get_animal_stats.php?id=${animalId}`);
        const data = await response.json();

        if (!data.success) {
            throw new Error(data.message);
        }

        const animal = data.animal;
        const card = document.querySelector(`.animal-card[data-id="${animalId}"]`);
        
        if (card) {
            // Enerji barını güncelle
            const energyBar = card.querySelector('.progress-bar[role="progressbar"]');
            if (energyBar) {
                energyBar.style.width = `${animal.energy}%`;
                energyBar.textContent = `Enerji: %${animal.energy}`;
                energyBar.className = `progress-bar bg-${getEnergyColor(animal.energy)}`;
            }

            // Besleme butonunu güncelle
            const feedButton = card.querySelector('.feed-button');
            if (feedButton) {
                feedButton.disabled = animal.energy >= 100;
            }
        }

    } catch (error) {
        console.error('Güncelleme hatası:', error);
        showAlert('Hayvan bilgileri güncellenirken hata oluştu', 'danger');
    }
}

// Sayfa yüklendiğinde çalışacak kodlar
document.addEventListener('DOMContentLoaded', () => {
    // Form doğrulama dinleyicileri
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', (e) => {
            if (!validateForm(form.id)) {
                e.preventDefault();
                showError('Lütfen tüm gerekli alanları doldurun!');
            }
        });
    });

    // Otomatik istatistik güncelleme (30 saniyede bir)
    if (document.querySelector('.animals-grid')) {
        setInterval(() => {
            document.querySelectorAll('.animal-card').forEach(card => {
                const animalId = card.getAttribute('data-id');
                if (animalId) {
                    updateAnimalCard(animalId);
                }
            });
        }, 30000);
    }

    // Bildirim dropdown'ı için tıklama olayı
    const notificationItems = document.querySelectorAll('.notification-item');
    notificationItems.forEach(item => {
        item.addEventListener('click', () => {
            const notificationId = item.getAttribute('data-id');
            if (notificationId) {
                markAsRead(notificationId);
            }
        });
    });
}); 