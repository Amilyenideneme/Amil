<?php
// CLI'dan çalıştırılıp çalıştırılmadığını kontrol et
if (php_sapi_name() !== 'cli') {
    die('Bu dosya sadece CLI\'dan çalıştırılabilir.');
}

// Gerekli dosyaları dahil et
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

try {
    // Başlangıç zamanını kaydet
    $startTime = microtime(true);
    
    // Hayvanları güncelle
    echo "Hayvanlar güncelleniyor...\n";
    updateAnimals();
    
    // Ölü hayvanları temizle
    echo "Ölü hayvanlar temizleniyor...\n";
    $deadCount = cleanDeadAnimals();
    echo "$deadCount ölü hayvan temizlendi.\n";
    
    // İşlem süresini hesapla
    $executionTime = microtime(true) - $startTime;
    echo "İşlem tamamlandı. Süre: " . number_format($executionTime, 2) . " saniye\n";
    
    // Log dosyasına kaydet
    $logMessage = date('Y-m-d H:i:s') . " - Cron başarıyla çalıştı. Süre: " . number_format($executionTime, 2) . " saniye\n";
    file_put_contents(__DIR__ . '/logs/cron.log', $logMessage, FILE_APPEND);
    
} catch (Exception $e) {
    // Hata durumunda log dosyasına kaydet
    $errorMessage = date('Y-m-d H:i:s') . " - HATA: " . $e->getMessage() . "\n";
    file_put_contents(__DIR__ . '/logs/cron_error.log', $errorMessage, FILE_APPEND);
    
    // Hata mesajını göster
    die("HATA: " . $e->getMessage() . "\n");
} 