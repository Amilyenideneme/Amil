-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 10 Kas 2024, 16:41:23
-- Sunucu sürümü: 8.0.30
-- PHP Sürümü: 8.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `sanal_ciftlik`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `action` enum('login','register','buy_animal','sell_animal','feed_animal','balance_request','balance_approved','balance_rejected','purchase') NOT NULL,
  `details` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `details`, `created_at`) VALUES
(1, 3, 'login', 'Kullanıcı giriş yaptı', '2024-11-10 15:43:29'),
(2, 3, 'login', 'Yeni hayvan alındı #1', '2024-11-10 15:51:08'),
(3, 3, 'login', 'Yeni hayvan alındı #2', '2024-11-10 16:00:17'),
(4, 3, 'login', 'Kullanıcı giriş yaptı', '2024-11-10 16:04:11'),
(5, 3, 'login', '500 TL bakiye yüklendi', '2024-11-10 16:39:54'),
(6, 3, 'login', 'Yeni hayvan alındı #3', '2024-11-10 16:40:05'),
(7, 3, 'login', '500 TL bakiye yüklendi', '2024-11-10 16:40:22'),
(8, 3, 'balance_request', '500 TL bakiye yükleme talebi oluşturuldu', '2024-11-10 16:51:45'),
(9, 3, 'balance_request', '500 TL bakiye yükleme talebi oluşturuldu', '2024-11-10 16:51:57'),
(10, 3, 'balance_approved', '500.00 TL bakiye yükleme talebi onaylandı', '2024-11-10 16:54:39'),
(11, 3, 'balance_rejected', '500.00 TL bakiye yükleme talebi reddedildi. Sebep: egeberhfrv', '2024-11-10 16:55:59'),
(12, 3, 'balance_request', '500 TL bakiye yükleme talebi oluşturuldu', '2024-11-10 16:56:34'),
(13, 3, 'balance_approved', '500.00 TL bakiye yükleme talebi onaylandı', '2024-11-10 17:01:31'),
(14, 3, 'balance_request', '500 TL bakiye yükleme talebi oluşturuldu', '2024-11-10 17:02:06'),
(15, 3, 'balance_rejected', '500.00 TL bakiye yükleme talebi reddedildi. Sebep: 8ki7ju6hy5gt4fre', '2024-11-10 17:02:28'),
(16, 3, 'balance_request', '500 TL bakiye yükleme talebi oluşturuldu', '2024-11-10 17:06:55'),
(17, 3, 'balance_rejected', '500.00 TL bakiye yükleme talebi reddedildi. Sebep: ssesevghijyuyu', '2024-11-10 17:07:19'),
(32, 3, 'buy_animal', 'Yeni hayvan alındı #7', '2024-11-10 17:13:05'),
(33, 3, 'login', 'Kullanıcı giriş yaptı', '2024-11-10 17:24:50'),
(34, 3, 'login', 'Kullanıcı giriş yaptı', '2024-11-10 17:32:43'),
(35, 3, 'login', 'Kullanıcı giriş yaptı', '2024-11-10 17:41:15'),
(36, 3, 'buy_animal', 'Yeni hayvan alındı #8', '2024-11-10 18:10:20'),
(37, 3, 'balance_request', '500 TL bakiye yükleme talebi oluşturuldu', '2024-11-10 18:26:44'),
(38, 3, 'balance_approved', '500.00 TL bakiye yükleme talebi onaylandı', '2024-11-10 18:27:02'),
(39, 3, 'buy_animal', 'Yeni hayvan alındı #9', '2024-11-10 18:39:22'),
(40, 3, 'buy_animal', 'Yeni hayvan alındı #10', '2024-11-10 20:06:42'),
(41, 3, 'buy_animal', 'Yeni hayvan alındı #11', '2024-11-10 20:06:57');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `animal_growth_history`
--

CREATE TABLE `animal_growth_history` (
  `id` int NOT NULL,
  `animal_id` int NOT NULL,
  `weight` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `animal_types`
--

CREATE TABLE `animal_types` (
  `id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `initial_weight` decimal(10,2) NOT NULL,
  `initial_price` decimal(10,2) NOT NULL,
  `growth_rate` decimal(5,2) NOT NULL,
  `selling_age` int NOT NULL,
  `profit_percentage` decimal(5,2) NOT NULL,
  `feeding_cost` decimal(10,2) NOT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `animal_types`
--

INSERT INTO `animal_types` (`id`, `name`, `initial_weight`, `initial_price`, `growth_rate`, `selling_age`, `profit_percentage`, `feeding_cost`, `active`, `created_at`, `updated_at`) VALUES
(1, 'Tavuk', 0.50, 50.00, 0.10, 30, 50.00, 5.00, 1, '2024-11-10 15:29:48', '2024-11-10 15:29:48'),
(2, 'Koyun', 5.00, 500.00, 0.30, 90, 75.00, 20.00, 1, '2024-11-10 15:29:48', '2024-11-10 15:29:48'),
(3, 'İnek', 30.00, 2000.00, 0.80, 180, 100.00, 50.00, 0, '2024-11-10 15:29:48', '2024-11-10 19:44:08'),
(4, 'M10', 0.30, 99.99, 0.49, 9, 10.00, 1.00, 1, '2024-11-10 16:08:03', '2024-11-10 16:08:03'),
(5, '282', 10.00, 2000.00, 0.50, 8, 200.00, 0.01, 0, '2024-11-10 16:35:41', '2024-11-10 17:19:27'),
(6, 'vfv', 3.10, 200.00, 0.48, 1, 100.00, 5.00, 1, '2024-11-10 18:39:11', '2024-11-10 18:39:11');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `balance_transactions`
--

CREATE TABLE `balance_transactions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` enum('deposit','withdrawal','purchase','sale') NOT NULL,
  `description` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `balance_transactions`
--

INSERT INTO `balance_transactions` (`id`, `user_id`, `amount`, `type`, `description`, `created_at`) VALUES
(1, 3, 100.00, 'deposit', 'Hoşgeldin bonusu', '2024-11-10 15:43:20'),
(2, 3, 500.00, 'deposit', 'Bakiye yükleme', '2024-11-10 16:39:54'),
(3, 3, 500.00, 'deposit', 'Bakiye yükleme', '2024-11-10 16:40:22'),
(4, 3, 99.99, 'purchase', 'M10 satın alındı', '2024-11-10 20:06:42'),
(5, 3, 200.00, 'purchase', 'vfv satın alındı', '2024-11-10 20:06:57');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `notifications`
--

CREATE TABLE `notifications` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('success','warning','danger','info') NOT NULL DEFAULT 'info',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 3, 'Bakiye Yükleme Onaylandı', '500.00 TL tutarındaki bakiye yükleme talebiniz onaylanmıştır.', 'success', 1, '2024-11-10 17:01:31'),
(2, 3, 'Bakiye Yükleme Reddedildi', '500.00 TL tutarındaki bakiye yükleme talebiniz reddedilmiştir. Sebep: 8ki7ju6hy5gt4fre', 'danger', 1, '2024-11-10 17:02:28'),
(3, 3, 'Bakiye Yükleme Reddedildi', '500.00 TL tutarındaki bakiye yükleme talebiniz reddedilmiştir. Sebep: ssesevghijyuyu', 'danger', 1, '2024-11-10 17:07:19'),
(4, 3, 'Bakiye Yükleme Onaylandı', '500.00 TL tutarındaki bakiye yükleme talebiniz onaylanmıştır.', 'success', 1, '2024-11-10 18:27:02');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `pending_balance_transactions`
--

CREATE TABLE `pending_balance_transactions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `proof_file` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_note` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `pending_balance_transactions`
--

INSERT INTO `pending_balance_transactions` (`id`, `user_id`, `amount`, `proof_file`, `status`, `admin_note`, `created_at`, `updated_at`) VALUES
(1, 3, 500.00, '6730ac6126880.jpg', 'rejected', 'egeberhfrv', '2024-11-10 16:51:45', '2024-11-10 16:55:59'),
(2, 3, 500.00, '6730ac6d7513d.jpg', 'approved', NULL, '2024-11-10 16:51:57', '2024-11-10 16:54:39'),
(3, 3, 500.00, '6730ad826156c.jpg', 'approved', NULL, '2024-11-10 16:56:34', '2024-11-10 17:01:31'),
(4, 3, 500.00, '6730aeced7be8.png', 'rejected', '8ki7ju6hy5gt4fre', '2024-11-10 17:02:06', '2024-11-10 17:02:28'),
(5, 3, 500.00, '6730afefecf67.jpeg', 'rejected', 'ssesevghijyuyu', '2024-11-10 17:06:55', '2024-11-10 17:07:19'),
(6, 3, 500.00, '6730c2a4a2b7b.png', 'approved', NULL, '2024-11-10 18:26:44', '2024-11-10 18:27:02');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `referral_earnings`
--

CREATE TABLE `referral_earnings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `referred_user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `referral_earnings`
--

INSERT INTO `referral_earnings` (`id`, `user_id`, `referred_user_id`, `amount`, `created_at`) VALUES
(1, 3, 5, 10.00, '2024-11-10 17:38:58'),
(2, 3, 6, 10.00, '2024-11-10 17:41:02');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `settings`
--

CREATE TABLE `settings` (
  `id` int NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `value` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'site_name', 'Sanal Çiftlik', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(2, 'site_description', 'Online Çiftlik Yönetim Oyunu', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(3, 'maintenance_mode', '0', '2024-11-10 17:19:01', '2024-11-10 17:25:13'),
(4, 'min_deposit', '10', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(5, 'max_deposit', '1000', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(6, 'min_withdrawal', '50', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(7, 'max_withdrawal', '5000', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(8, 'daily_bonus', '5', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(9, 'referral_bonus', '10', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(10, 'growth_multiplier', '1', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(11, 'feed_cost_multiplier', '1', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(12, 'profit_multiplier', '1', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(13, 'market_fee', '5', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(14, 'min_market_price', '1', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(15, 'max_market_price', '100000', '2024-11-10 17:19:01', '2024-11-10 17:19:01'),
(16, 'feeding_interval', '1', '2024-11-10 18:35:19', '2024-11-10 19:45:47'),
(17, 'energy_decay_rate', '1', '2024-11-10 18:35:19', '2024-11-10 18:35:19');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `balance` decimal(10,2) DEFAULT '0.00',
  `is_admin` tinyint(1) DEFAULT '0',
  `is_banned` tinyint(1) DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `referral_code` varchar(10) DEFAULT NULL,
  `referred_by` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `balance`, `is_admin`, `is_banned`, `last_login`, `created_at`, `updated_at`, `referral_code`, `referred_by`) VALUES
(1, 'admin', 'admin@example.com', '$2y$10$example_hash', 1000.00, 1, 0, NULL, '2024-11-10 15:29:48', '2024-11-10 17:22:49', 'ad5320a9', NULL),
(2, 'test_user', 'test@example.com', '$2y$10$example_hash', 600.00, 0, 0, NULL, '2024-11-10 15:29:48', '2024-11-10 17:22:49', '6997b5fb', NULL),
(3, 'yenibir', 'ddhjjhs@gmail.com', '$2y$10$wGKEZKQ1Mq77MCCN04lAsunBPJC7KhgrMX7nCYZ5Azdrn6sB1lZRe', 920.02, 1, 0, '2024-11-10 17:41:15', '2024-11-10 15:43:20', '2024-11-10 20:06:57', '2cd67b4a', NULL),
(4, 'amil12', 'ddhjhghjhs@gmail.com', '$2y$10$tF.LRmetp0AGL6dG/MnkaOxAEgwbz5YeV6TVWT/43uW7MDjRbvcs6', 0.00, 0, 0, NULL, '2024-11-10 17:37:46', '2024-11-10 17:37:46', '3337065f', 3),
(5, 'admin11', 'ddgyhujikhjjhs@gmail.com', '$2y$10$KVud35vqp4efhi6xsJ05XeWkjzoexCna7rk89Qz26F7tKo9uHg0IG', 0.00, 0, 0, NULL, '2024-11-10 17:38:58', '2024-11-10 17:38:58', 'c369bb58', 3),
(6, 'admin55', 'desrdtfyghjkdhjjhs@gmail.com', '$2y$10$EnG2GnN65UyJNLI1i5pMXeNdnDlaZF1VcL0kvPZwZ6C9alrtfU/f2', 0.00, 0, 0, NULL, '2024-11-10 17:41:02', '2024-11-10 17:41:02', '5893d221', 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `user_animals`
--

CREATE TABLE `user_animals` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `animal_type_id` int NOT NULL,
  `age` decimal(10,2) DEFAULT '0.00',
  `weight` decimal(10,2) NOT NULL,
  `health` int DEFAULT '100',
  `energy` int DEFAULT '100',
  `feeding_status` int DEFAULT '100',
  `price` decimal(10,2) NOT NULL,
  `last_fed` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Tablo döküm verisi `user_animals`
--

INSERT INTO `user_animals` (`id`, `user_id`, `animal_type_id`, `age`, `weight`, `health`, `energy`, `feeding_status`, `price`, `last_fed`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 0.00, 0.50, 100, 100, 100, 50.00, '2024-11-10 19:29:27', '2024-11-10 15:51:08', '2024-11-10 19:29:27'),
(2, 3, 1, 0.00, 0.50, 100, 100, 100, 50.00, '2024-11-10 19:29:27', '2024-11-10 16:00:17', '2024-11-10 19:29:27'),
(3, 3, 2, 0.00, 5.00, 100, 100, 100, 500.00, '2024-11-10 19:29:27', '2024-11-10 16:40:05', '2024-11-10 19:29:27'),
(7, 3, 2, 0.00, 5.00, 100, 100, 100, 500.00, '2024-11-10 19:29:27', '2024-11-10 17:13:05', '2024-11-10 19:29:27'),
(8, 3, 4, 0.00, 0.30, 100, 100, 100, 99.99, '2024-11-10 19:29:27', '2024-11-10 18:10:20', '2024-11-10 19:29:27'),
(9, 3, 6, 0.00, 3.10, 100, 100, 100, 200.00, '2024-11-10 19:29:27', '2024-11-10 18:39:22', '2024-11-10 19:29:27'),
(10, 3, 4, 0.00, 0.30, 100, 100, 100, 99.99, '2024-11-10 20:06:42', '2024-11-10 20:06:42', '2024-11-10 20:06:42'),
(11, 3, 6, 0.00, 3.10, 100, 100, 100, 200.00, '2024-11-10 20:06:57', '2024-11-10 20:06:57', '2024-11-10 20:06:57');

--
-- Tetikleyiciler `user_animals`
--
DELIMITER $$
CREATE TRIGGER `after_animal_purchase` AFTER INSERT ON `user_animals` FOR EACH ROW BEGIN
    INSERT INTO activity_logs (user_id, action, details)
    VALUES (NEW.user_id, 'buy_animal', CONCAT('Yeni hayvan alındı #', NEW.id));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_animal_sale` AFTER DELETE ON `user_animals` FOR EACH ROW BEGIN
    INSERT INTO balance_transactions (user_id, amount, type, description)
    VALUES (OLD.user_id, OLD.price, 'sale', CONCAT('Hayvan satışı #', OLD.id));
    
    UPDATE users SET balance = balance + OLD.price WHERE id = OLD.user_id;
END
$$
DELIMITER ;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `animal_growth_history`
--
ALTER TABLE `animal_growth_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `animal_id` (`animal_id`);

--
-- Tablo için indeksler `animal_types`
--
ALTER TABLE `animal_types`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `balance_transactions`
--
ALTER TABLE `balance_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_balance_transactions_user` (`user_id`);

--
-- Tablo için indeksler `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `pending_balance_transactions`
--
ALTER TABLE `pending_balance_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `referral_earnings`
--
ALTER TABLE `referral_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `referred_user_id` (`referred_user_id`);

--
-- Tablo için indeksler `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `referral_code` (`referral_code`),
  ADD KEY `referred_by` (`referred_by`);

--
-- Tablo için indeksler `user_animals`
--
ALTER TABLE `user_animals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_animals_user` (`user_id`),
  ADD KEY `idx_user_animals_type` (`animal_type_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- Tablo için AUTO_INCREMENT değeri `animal_growth_history`
--
ALTER TABLE `animal_growth_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `animal_types`
--
ALTER TABLE `animal_types`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `balance_transactions`
--
ALTER TABLE `balance_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `pending_balance_transactions`
--
ALTER TABLE `pending_balance_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `referral_earnings`
--
ALTER TABLE `referral_earnings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Tablo için AUTO_INCREMENT değeri `user_animals`
--
ALTER TABLE `user_animals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `animal_growth_history`
--
ALTER TABLE `animal_growth_history`
  ADD CONSTRAINT `animal_growth_history_ibfk_1` FOREIGN KEY (`animal_id`) REFERENCES `user_animals` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `balance_transactions`
--
ALTER TABLE `balance_transactions`
  ADD CONSTRAINT `balance_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `pending_balance_transactions`
--
ALTER TABLE `pending_balance_transactions`
  ADD CONSTRAINT `pending_balance_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Tablo kısıtlamaları `referral_earnings`
--
ALTER TABLE `referral_earnings`
  ADD CONSTRAINT `referral_earnings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `referral_earnings_ibfk_2` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`);

--
-- Tablo kısıtlamaları `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`referred_by`) REFERENCES `users` (`id`);

--
-- Tablo kısıtlamaları `user_animals`
--
ALTER TABLE `user_animals`
  ADD CONSTRAINT `user_animals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_animals_ibfk_2` FOREIGN KEY (`animal_type_id`) REFERENCES `animal_types` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
