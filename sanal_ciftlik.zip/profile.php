<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'auth.php';

// Oturum kontrolü
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Form gönderildi mi kontrol et
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        $email = cleanInput($_POST['email'] ?? '');

        // E-posta değişikliği
        if ($email !== '') {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Geçersiz e-posta adresi!");
            }

            // E-posta adresi başka kullanıcı tarafından kullanılıyor mu?
            $stmt = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $_SESSION['user_id']]);
            if ($stmt->rowCount() > 0) {
                throw new Exception("Bu e-posta adresi başka bir kullanıcı tarafından kullanılıyor!");
            }

            // E-posta güncelle
            $stmt = $db->prepare("UPDATE users SET email = ? WHERE id = ?");
            $stmt->execute([$email, $_SESSION['user_id']]);
            $_SESSION['success'] = "E-posta adresiniz başarıyla güncellendi!";
        }

        // Şifre değişikliği
        if ($currentPassword !== '') {
            // Mevcut şifreyi kontrol et
            $stmt = $db->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!password_verify($currentPassword, $user['password'])) {
                throw new Exception("Mevcut şifreniz hatalı!");
            }

            if (strlen($newPassword) < 6) {
                throw new Exception("Yeni şifre en az 6 karakter olmalıdır!");
            }

            if ($newPassword !== $confirmPassword) {
                throw new Exception("Yeni şifreler eşleşmiyor!");
            }

            // Şifreyi güncelle
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $_SESSION['user_id']]);
            $_SESSION['success'] = "Şifreniz başarıyla güncellendi!";
        }

        header('Location: profile.php');
        exit;

    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
}

// Kullanıcı bilgilerini al
$stmt = $db->prepare("
    SELECT u.*, 
           COUNT(ua.id) as total_animals,
           SUM(ua.price) as total_animal_value
    FROM users u
    LEFT JOIN user_animals ua ON u.id = ua.user_id
    WHERE u.id = ?
    GROUP BY u.id
");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Header'ı dahil et
$pageTitle = "Profil";
include 'templates/header.php';
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2 class="mb-0">Profil Bilgileri</h2>
                </div>
                <div class="card-body">
                    <!-- Kullanıcı İstatistikleri -->
                    <div class="user-stats mb-4">
                        <div class="row text-center">
                            <div class="col-md-4">
                                <h5>Bakiye</h5>
                                <p class="h4"><?php echo formatMoney($user['balance']); ?></p>
                            </div>
                            <div class="col-md-4">
                                <h5>Toplam Hayvan</h5>
                                <p class="h4"><?php echo $user['total_animals']; ?></p>
                            </div>
                            <div class="col-md-4">
                                <h5>Toplam Değer</h5>
                                <p class="h4"><?php echo formatMoney($user['total_animal_value']); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Profil Güncelleme Formu -->
                    <form method="POST" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label class="form-label">Kullanıcı Adı</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">E-posta</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>">
                        </div>

                        <hr>

                        <h4 class="mb-3">Şifre Değiştir</h4>
                        
                        <div class="mb-3">
                            <label class="form-label">Mevcut Şifre</label>
                            <input type="password" name="current_password" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Yeni Şifre</label>
                            <input type="password" name="new_password" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Yeni Şifre (Tekrar)</label>
                            <input type="password" name="confirm_password" class="form-control">
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Güncelle</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- İşlem Geçmişi -->
            <div class="card mt-4">
                <div class="card-header">
                    <h3 class="mb-0">Son İşlemler</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tarih</th>
                                    <th>İşlem</th>
                                    <th>Tutar</th>
                                    <th>Açıklama</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stmt = $db->prepare("
                                    SELECT 
                                        bt.*,
                                        CASE 
                                            WHEN bt.type = 'deposit' THEN 'Bakiye Yükleme'
                                            WHEN bt.type = 'withdrawal' THEN 'Bakiye Çekme'
                                            WHEN bt.type = 'purchase' THEN 'Satın Alma'
                                            WHEN bt.type = 'sale' THEN 'Satış'
                                            ELSE bt.type
                                        END as transaction_type,
                                        CASE 
                                            WHEN bt.type IN ('deposit', 'sale') THEN 'text-success'
                                            WHEN bt.type IN ('withdrawal', 'purchase') THEN 'text-danger'
                                            ELSE ''
                                        END as amount_class
                                    FROM balance_transactions bt
                                    WHERE bt.user_id = ?
                                    ORDER BY bt.created_at DESC
                                    LIMIT 10
                                ");
                                $stmt->execute([$_SESSION['user_id']]);
                                $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                foreach ($transactions as $transaction) {
                                    echo "<tr>";
                                    echo "<td>" . date('d.m.Y H:i', strtotime($transaction['created_at'])) . "</td>";
                                    echo "<td>" . htmlspecialchars($transaction['type']) . "</td>";
                                    echo "<td class='" . $transaction['amount_class'] . "'>";
                                    echo in_array($transaction['type'], ['withdrawal', 'purchase']) ? '-' : '+';
                                    echo formatMoney($transaction['amount']) . "</td>";
                                    echo "<td>" . htmlspecialchars($transaction['description'] ?? '') . "</td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Referans Bilgileri -->
            <div class="card mt-4">
                <div class="card-header">
                    <h3 class="mb-0">Referans Bilgileri</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Referans Kodunuz</h5>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" value="<?php echo $user['referral_code']; ?>" readonly>
                                <button class="btn btn-outline-primary" onclick="copyToClipboard(this)" 
                                        data-clipboard-text="<?php echo $user['referral_code']; ?>">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                            
                            <h5 class="mt-4">Referans Linkiniz</h5>
                            <?php 
                            $referralLink = SITE_URL . '/register.php?ref=' . $user['referral_code'];
                            ?>
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" value="<?php echo $referralLink; ?>" readonly>
                                <button class="btn btn-outline-primary" onclick="copyToClipboard(this)" 
                                        data-clipboard-text="<?php echo $referralLink; ?>">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                            
                            <div class="mt-3">
                                <!-- Sosyal medya paylaşım butonları -->
                                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($referralLink); ?>" 
                                   class="btn btn-sm btn-primary" target="_blank">
                                    <i class="fab fa-facebook"></i> Paylaş
                                </a>
                                
                                <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode($referralLink); ?>&text=<?php echo urlencode('Sanal Çiftlik oyununa katıl!'); ?>" 
                                   class="btn btn-sm btn-info" target="_blank">
                                    <i class="fab fa-twitter"></i> Tweet
                                </a>
                                
                                <a href="https://wa.me/?text=<?php echo urlencode('Sanal Çiftlik oyununa katıl: ' . $referralLink); ?>" 
                                   class="btn btn-sm btn-success" target="_blank">
                                    <i class="fab fa-whatsapp"></i> WhatsApp
                                </a>
                            </div>
                            
                            <p class="text-muted mt-2">Bu kodu veya linki arkadaşlarınızla paylaşın</p>
                        </div>
                        
                        <div class="col-md-6">
                            <h5>Referans Kazançları</h5>
                            <?php
                            $stmt = $db->prepare("
                                SELECT SUM(amount) as total 
                                FROM referral_earnings 
                                WHERE user_id = ?
                            ");
                            $stmt->execute([$_SESSION['user_id']]);
                            $totalEarnings = $stmt->fetchColumn();
                            ?>
                            <h3 class="text-success"><?php echo formatMoney($totalEarnings); ?></h3>
                            <p class="text-muted">Toplam referans kazancı</p>
                        </div>
                    </div>
                    
                    <!-- Referans Kazançları Tablosu -->
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Kullanıcı</th>
                                    <th>Yüklenen</th>
                                    <th>Bonus %</th>
                                    <th>Kazanç</th>
                                    <th>Tarih</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $stmt = $db->prepare("
                                    SELECT 
                                        re.*,
                                        u.username 
                                    FROM referral_earnings re
                                    JOIN users u ON re.referred_user_id = u.id
                                    WHERE re.user_id = ?
                                    ORDER BY re.created_at DESC
                                    LIMIT 10
                                ");
                                $stmt->execute([$_SESSION['user_id']]);
                                $referrals = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($referrals as $referral) {
                                    echo "<tr>";
                                    echo "<td>" . htmlspecialchars($referral['username']) . "</td>";
                                    echo "<td>" . formatMoney($referral['transaction_amount']) . "</td>";
                                    echo "<td>%" . number_format($referral['percentage'], 1) . "</td>";
                                    echo "<td>" . formatMoney($referral['amount']) . "</td>";
                                    echo "<td>" . formatTime($referral['created_at']) . "</td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyToClipboard(button) {
    const text = button.dataset.clipboardText;
    navigator.clipboard.writeText(text).then(() => {
        const icon = button.querySelector('i');
        const originalClass = icon.className;
        icon.className = 'fas fa-check';
        
        // Başarılı kopyalama bildirimi göster
        const toast = new bootstrap.Toast(document.createElement('div'));
        toast.show();
        
        setTimeout(() => {
            icon.className = originalClass;
        }, 2000);
    });
}
</script>

<style>
.social-share-buttons {
    margin-top: 15px;
}

.social-share-buttons .btn {
    margin-right: 5px;
}

.btn-facebook {
    background-color: #3b5998;
    color: white;
}

.btn-twitter {
    background-color: #1da1f2;
    color: white;
}

.btn-whatsapp {
    background-color: #25d366;
    color: white;
}
</style>

<?php include 'templates/footer.php'; ?> 