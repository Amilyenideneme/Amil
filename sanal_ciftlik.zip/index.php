<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'auth.php';

// Oturum kontrolü
session_start();

// Header'ı dahil et
include 'templates/header.php';

// Kullanıcının bakiyesini ve hayvanlarını al
$userBalance = 0;
$animals = [];

if (isset($_SESSION['user_id'])) {
    // Bakiyeyi al
    $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $userBalance = $stmt->fetchColumn();

    // Hayvanları getir
    $stmt = $db->prepare("
        SELECT 
            ua.*,
            at.name as animal_type,
            at.selling_age,
            at.feeding_cost
        FROM user_animals ua 
        JOIN animal_types at ON ua.animal_type_id = at.id 
        WHERE ua.user_id = ?
        ORDER BY ua.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $animals = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container">
    <?php if (isset($_SESSION['user_id'])): ?>
        <!-- Kullanıcı bilgileri -->
        <div class="user-info">
            <h3><i class="fas fa-user-circle"></i> Hoş geldin, <?php echo htmlspecialchars($_SESSION['username']); ?></h3>
            <p><i class="fas fa-wallet"></i> Bakiyeniz: <span class="balance"><?php echo formatMoney($userBalance); ?> TL</span></p>
            <div class="user-actions">
                <a href="add_balance.php" class="btn btn-success"><i class="fas fa-plus-circle"></i> Bakiye Ekle</a>
                <a href="store.php" class="btn btn-primary"><i class="fas fa-store"></i> Mağazaya Git</a>
            </div>
        </div>

        <!-- Ana dashboard -->
        <div class="dashboard">
            <div class="my-animals-container">
                <div class="section-header">
                    <div class="d-flex align-items-center">
                        <h2><i class="fas fa-paw me-2"></i> Hayvanlarım</h2>
                        <span class="animal-count ms-3">Toplam: <?php echo count($animals); ?></span>
                    </div>
                    <a href="store.php" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Yeni Hayvan Al
                    </a>
                </div>

                <?php if (empty($animals)): ?>
                    <div class="empty-state">
                        <div class="empty-icon">
                            <i class="fas fa-paw"></i>
                        </div>
                        <h3>Henüz Hayvanınız Yok</h3>
                        <p>Mağazadan yeni hayvanlar alarak çiftliğinizi büyütebilirsiniz.</p>
                        <a href="store.php" class="btn btn-primary">
                            <i class="fas fa-store"></i> Mağazaya Git
                        </a>
                    </div>
                <?php else: ?>
                    <div class="animals-grid">
                        <?php foreach ($animals as $animal): ?>
                            <div class="animal-card" data-id="<?php echo $animal['id']; ?>">
                                <div class="animal-header">
                                    <div class="animal-type">
                                        <i class="fas fa-<?php echo getAnimalIcon($animal['animal_type']); ?>"></i>
                                        <h3><?php echo htmlspecialchars($animal['animal_type']); ?></h3>
                                    </div>
                                    <span class="animal-age-badge">
                                        <?php echo $animal['age']; ?> gün
                                    </span>
                                </div>

                                <div class="animal-stats">
                                    <div class="stat-item">
                                        <label>
                                            <i class="fas fa-heartbeat"></i> Sağlık
                                        </label>
                                        <div class="progress">
                                            <div class="progress-bar bg-<?php echo getHealthColor($animal['health']); ?>" 
                                                 role="progressbar" 
                                                 style="width: <?php echo $animal['health']; ?>%">
                                                %<?php echo $animal['health']; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="stat-item">
                                        <label>
                                            <i class="fas fa-battery-half"></i> Enerji
                                        </label>
                                        <div class="progress">
                                            <div class="progress-bar bg-<?php echo getEnergyColor($animal['energy']); ?>" 
                                                 role="progressbar" 
                                                 style="width: <?php echo $animal['energy']; ?>%">
                                                %<?php echo $animal['energy']; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="stat-row">
                                        <div class="stat-col">
                                            <label><i class="fas fa-weight"></i> Ağırlık</label>
                                            <span><?php echo number_format($animal['weight'], 1); ?> kg</span>
                                        </div>
                                        <div class="stat-col">
                                            <label><i class="fas fa-coins"></i> Değer</label>
                                            <span><?php echo formatMoney($animal['price']); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="animal-actions">
                                    <div class="feeding-controls">
                                        <div class="feeding-timer mb-2" 
                                             data-last-fed="<?php echo $animal['last_fed']; ?>" 
                                             data-interval="60">
                                            <div class="progress">
                                                <div class="progress-bar" role="progressbar" style="width: 0%"></div>
                                            </div>
                                            <small class="timer-text">Yükleniyor...</small>
                                        </div>
                                        
                                        <button onclick="feedAnimal(<?php echo $animal['id']; ?>)" 
                                                class="btn btn-success btn-sm w-100 feed-button" 
                                                data-animal-id="<?php echo $animal['id']; ?>">
                                            <i class="fas fa-utensils"></i> Besle
                                            <span class="feed-cost">(<?php echo formatMoney($animal['feeding_cost']); ?>)</span>
                                        </button>
                                    </div>

                                    <?php if ($animal['age'] >= $animal['selling_age']): ?>
                                        <button onclick="sellAnimal(<?php echo $animal['id']; ?>)" 
                                                class="btn btn-warning btn-sm w-100">
                                            <i class="fas fa-coins"></i> Sat
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm w-100" disabled>
                                            <i class="fas fa-clock"></i> <?php echo $animal['selling_age'] - $animal['age']; ?> gün kaldı
                                        </button>
                                    <?php endif; ?>
                                    
                                    <button onclick="showAnimalDetails(<?php echo $animal['id']; ?>)" 
                                            class="btn btn-info btn-sm w-100">
                                        <i class="fas fa-info-circle"></i> Detaylar
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <!-- Giriş yapılmamışsa -->
        <div class="welcome">
            <h1><?php echo SITE_NAME; ?>'e Hoş Geldiniz</h1>
            <p>Kendi sanal çiftliğinizi oluşturun, hayvanlar yetiştirin ve kâr elde edin!</p>
            <div class="auth-buttons">
                <a href="login.php" class="btn">Giriş Yap</a>
                <a href="register.php" class="btn">Kayıt Ol</a>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Hayvan Detay Modal -->
<div class="modal fade" id="animalModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Hayvan Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="animalDetailsContent">
                    <!-- Detaylar AJAX ile yüklenecek -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript kodları -->
<script>
// Besleme fonksiyonu
async function feedAnimal(animalId) {
    try {
        const formData = new FormData();
        formData.append('animal_id', animalId);

        const response = await fetch('actions/feed_animal.php', {
            method: 'POST',
            body: formData
        });

        // Debug için
        const responseText = await response.text();
        console.log('Server response:', responseText);

        let data;
        try {
            data = JSON.parse(responseText);
        } catch (e) {
            console.error('JSON parse error:', e);
            console.error('Raw response:', responseText);
            throw new Error('Sunucu yanıtı geçersiz');
        }

        if (data.success) {
            showAlert('Hayvan başarıyla beslendi!', 'success');
            setTimeout(() => location.reload(), 1500);
        } else {
            throw new Error(data.message || 'Besleme işlemi başarısız oldu');
        }

    } catch (error) {
        console.error('Besleme hatası:', error);
        showAlert(error.message, 'danger');
    }
}

// Alert gösterme fonksiyonu
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = '9999';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    document.body.appendChild(alertDiv);
    
    setTimeout(() => alertDiv.remove(), 3000);
}

// Zamanlayıcı güncelleme fonksiyonu
function updateFeedingTimer(timer) {
    if (!timer) return;
    
    const lastFed = new Date(timer.dataset.lastFed);
    const intervalMinutes = parseInt(timer.dataset.interval);
    
    if (isNaN(lastFed.getTime()) || isNaN(intervalMinutes)) {
        console.error('Geçersiz değerler:', {lastFed, intervalMinutes});
        return;
    }

    const now = new Date();
    const diffInMinutes = Math.floor((now - lastFed) / (1000 * 60));
    const remainingMinutes = Math.max(0, intervalMinutes - diffInMinutes);
    
    const progress = Math.min(100, (diffInMinutes / intervalMinutes) * 100);
    
    const progressBar = timer.querySelector('.progress-bar');
    const timerText = timer.querySelector('.timer-text');
    const feedButton = timer.closest('.feeding-controls').querySelector('.feed-button');
    
    if (progressBar) {
        progressBar.style.width = `${progress}%`;
        progressBar.className = `progress-bar ${remainingMinutes <= 0 ? 'bg-success' : 'bg-warning'}`;
    }
    
    if (timerText) {
        timerText.textContent = remainingMinutes <= 0 ? 'Beslenebilir' : `${remainingMinutes} dakika kaldı`;
    }
    
    if (feedButton) {
        feedButton.disabled = remainingMinutes > 0;
        feedButton.classList.toggle('disabled', remainingMinutes > 0);
    }
}

// Tüm zamanlayıcıları başlat
function startAllTimers() {
    const timers = document.querySelectorAll('.feeding-timer');
    
    timers.forEach(timer => {
        updateFeedingTimer(timer);
        
        // Var olan interval'i temizle
        if (timer.dataset.intervalId) {
            clearInterval(parseInt(timer.dataset.intervalId));
        }
        
        // Yeni interval oluştur
        const intervalId = setInterval(() => updateFeedingTimer(timer), 60000);
        timer.dataset.intervalId = intervalId;
    });
}

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    startAllTimers();
});

function sellAnimal(animalId) {
    if (confirm('Hayvanı satmak istediğinize emin misiniz?')) {
        fetch('actions/sell_animal.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                animal_id: animalId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Hayvan başarıyla satıldı!');
                location.reload();
            } else {
                alert(data.message);
            }
        });
    }
}

async function showAnimalDetails(animalId) {
    const modalContent = document.getElementById('animalDetailsContent');
    modalContent.innerHTML = `
        <div class="text-center">
            <div class="spinner-border" role="status">
                <span class="visually-hidden">Yükleniyor...</span>
            </div>
        </div>
    `;

    // Modal'ı göster
    const modal = new bootstrap.Modal(document.getElementById('animalModal'));
    modal.show();

    try {
        const response = await fetch(`actions/get_animal_details.php?id=${animalId}`);
        const data = await response.json();
        
        if (data.success) {
            const details = data.animal;
            const content = `
                <div class="animal-details">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="detail-item mb-3">
                                <i class="fas fa-paw"></i>
                                <strong>Tür:</strong> ${details.animal_type}
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-birthday-cake"></i>
                                <strong>Yaş:</strong> ${details.age} gün
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-weight"></i>
                                <strong>Kilo:</strong> ${details.weight} kg
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-coins"></i>
                                <strong>Değer:</strong> ${formatMoney(details.price)}
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="detail-item mb-3">
                                <i class="fas fa-heartbeat"></i>
                                <strong>Sağlık:</strong>
                                <div class="progress mt-1">
                                    <div class="progress-bar bg-${getHealthColor(details.health)}" 
                                         style="width: ${details.health}%">
                                        %${details.health}
                                    </div>
                                </div>
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-battery-half"></i>
                                <strong>Enerji:</strong>
                                <div class="progress mt-1">
                                    <div class="progress-bar bg-${getEnergyColor(details.energy)}" 
                                         style="width: ${details.energy}%">
                                        %${details.energy}
                                    </div>
                                </div>
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-utensils"></i>
                                <strong>Beslenme Durumu:</strong> 
                                <span class="badge bg-${details.feeding_status === 'Beslenebilir' ? 'success' : 'warning'}">
                                    ${details.feeding_status}
                                </span>
                                <br>
                                <small class="text-muted ms-4">
                                    ${details.next_feeding}
                                </small>
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-history"></i>
                                <strong>Son Beslenme:</strong> ${details.last_fed}
                            </div>
                            <div class="detail-item mb-3">
                                <i class="fas fa-clock"></i>
                                <strong>Oluşturulma:</strong> ${details.created_at}
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            modalContent.innerHTML = content;
        } else {
            throw new Error(data.message || 'Hayvan detayları alınamadı');
        }
    } catch (error) {
        console.error('Detay getirme hatası:', error);
        modalContent.innerHTML = `
            <div class="alert alert-danger">
                Hayvan detayları yüklenirken bir hata oluştu: ${error.message}
            </div>
        `;
    }
}

function formatMoney(amount) {
    return new Intl.NumberFormat('tr-TR', {
        style: 'currency',
        currency: 'TRY'
    }).format(amount);
}
</script>

<style>
.animal-card {
    background: white;
    border-radius: 15px;
    padding: 20px;
    box-shadow: 0 2px 15px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
}

.animal-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 20px rgba(0,0,0,0.12);
}

.animal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.animal-type {
    display: flex;
    align-items: center;
    gap: 12px;
}

.animal-type i {
    font-size: 24px;
    color: #3498db;
}

.animal-type h3 {
    margin: 0;
    font-size: 1.2rem;
    color: #2c3e50;
}

.animal-age-badge {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: 500;
}

.stat-item {
    margin-bottom: 15px;
}

.stat-item label {
    display: block;
    margin-bottom: 5px;
    color: #666;
    font-size: 0.9rem;
}

.stat-item i {
    margin-right: 8px;
}

.stat-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-top: 15px;
}

.stat-col {
    text-align: center;
    background: #f8f9fa;
    padding: 10px;
    border-radius: 8px;
}

.stat-col label {
    display: block;
    color: #666;
    font-size: 0.85rem;
    margin-bottom: 5px;
}

.stat-col span {
    font-weight: 600;
    color: #2c3e50;
}

.animal-actions {
    margin-top: 20px;
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.empty-state {
    text-align: center;
    padding: 40px 20px;
    background: #f8f9fa;
    border-radius: 15px;
    border: 2px dashed #dee2e6;
}

.empty-icon {
    font-size: 48px;
    color: #adb5bd;
    margin-bottom: 20px;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
}

.animal-count {
    background: #e8f5e9;
    color: #2e7d32;
    padding: 5px 15px;
    border-radius: 20px;
    font-weight: 500;
}

@media (max-width: 768px) {
    .animals-grid {
        grid-template-columns: 1fr;
    }
    
    .stat-row {
        grid-template-columns: 1fr;
    }
}

.detail-item {
    padding: 10px;
    border-radius: 8px;
    background: #f8f9fa;
    margin-bottom: 10px;
}

.detail-item i {
    width: 25px;
    color: #666;
}

.detail-item strong {
    margin-right: 8px;
}

.progress {
    height: 10px;
    margin-top: 8px;
}

.badge {
    padding: 5px 10px;
    font-weight: normal;
}

.feeding-controls {
    margin-bottom: 10px;
}

.feeding-timer {
    position: relative;
    margin-bottom: 10px;
}

.feeding-timer .progress {
    height: 6px;
    border-radius: 3px;
}

.timer-text {
    font-size: 0.8rem;
    color: #666;
    margin-top: 2px;
    display: block;
    text-align: center;
}

.feed-button:not(.disabled) {
    cursor: pointer;
}

.feed-button.disabled {
    opacity: 0.7;
    cursor: not-allowed;
}

.feed-cost {
    font-size: 0.8rem;
    opacity: 0.8;
}

.alert {
    max-width: 90%;
    width: 400px;
}
</style>

<?php
include 'templates/footer.php';
?> 