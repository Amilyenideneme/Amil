<?php
// Hata raporlamayı kapatın
error_reporting(0);
ini_set('display_errors', 0);

// Çıktı tamponlamayı başlat
ob_start();

// Session ve header ayarları
session_start();
header('Content-Type: application/json');

// Gerekli dosyaları dahil et
require_once '../config.php';
require_once '../functions.php';

// Ana işlem bloğu
try {
    // Debug için
    error_log("Feed animal request received: " . print_r($_POST, true));
    
    // Oturum kontrolü
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Oturum açmanız gerekiyor');
    }

    // POST verisi kontrolü
    $animalId = filter_input(INPUT_POST, 'animal_id', FILTER_VALIDATE_INT);
    
    if (!$animalId) {
        throw new Exception('Geçerli bir hayvan ID\'si gerekli');
    }

    // Veritabanı işlemleri
    $db->beginTransaction();

    // Hayvan ve kullanıcı kontrolü
    $stmt = $db->prepare("
        SELECT ua.*, at.feeding_cost 
        FROM user_animals ua 
        JOIN animal_types at ON ua.animal_type_id = at.id 
        WHERE ua.id = ? AND ua.user_id = ?
        FOR UPDATE
    ");
    $stmt->execute([$animalId, $_SESSION['user_id']]);
    $animal = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$animal) {
        throw new Exception('Hayvan bulunamadı veya size ait değil');
    }

    // Bakiye kontrolü
    $stmt = $db->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
    $stmt->execute([$_SESSION['user_id']]);
    $balance = $stmt->fetchColumn();

    if ($balance < $animal['feeding_cost']) {
        throw new Exception('Yetersiz bakiye');
    }

    // Bakiyeyi güncelle
    $stmt = $db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
    $stmt->execute([$animal['feeding_cost'], $_SESSION['user_id']]);

    // Hayvanı güncelle
    $stmt = $db->prepare("
        UPDATE user_animals 
        SET energy = LEAST(100, energy + 30),
            health = CASE 
                WHEN health < 80 THEN LEAST(100, health + 10)
                ELSE health
            END,
            last_fed = NOW()
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$animalId, $_SESSION['user_id']]);

    // İşlemi tamamla
    $db->commit();

    // Tampondaki çıktıyı temizle
    ob_clean();

    // Başarılı yanıt
    echo json_encode([
        'success' => true,
        'message' => 'Hayvan başarıyla beslendi'
    ]);

} catch (Exception $e) {
    // Hata durumunda rollback
    if ($db->inTransaction()) {
        $db->rollBack();
    }

    // Tampondaki çıktıyı temizle
    ob_clean();

    // Hata yanıtı
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);

    // Hatayı logla
    error_log("Feed animal error: " . $e->getMessage());
}

// Çıktı tamponlamasını sonlandır
ob_end_flush();