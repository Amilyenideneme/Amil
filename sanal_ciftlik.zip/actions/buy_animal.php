<?php
// Önceki çıktıları temizle
if (ob_get_level()) ob_end_clean();

// JSON header'ı ayarla
header('Content-Type: application/json; charset=utf-8');

// Hata gösterimini kapat
error_reporting(0);
ini_set('display_errors', 0);

try {
    require_once __DIR__ . '/../config.php';
    require_once __DIR__ . '/../functions.php';
    require_once __DIR__ . '/../auth.php';

    // Session kontrolü
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Oturum açmanız gerekiyor');
    }

    // POST verilerini al
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (!$data || !isset($data['animal_type_id'])) {
        throw new Exception('Geçersiz istek verisi');
    }

    $animalTypeId = (int)$data['animal_type_id'];
    $userId = $_SESSION['user_id'];

    // Veritabanı işlemlerini başlat
    $db->beginTransaction();

    try {
        // Hayvan türü bilgilerini al
        $stmt = $db->prepare("SELECT * FROM animal_types WHERE id = ? AND active = 1");
        $stmt->execute([$animalTypeId]);
        $animalType = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$animalType) {
            throw new Exception('Geçersiz hayvan türü');
        }

        // Kullanıcı bakiyesini kontrol et
        $stmt = $db->prepare("SELECT balance FROM users WHERE id = ? FOR UPDATE");
        $stmt->execute([$userId]);
        $userBalance = $stmt->fetchColumn();

        if ($userBalance < $animalType['initial_price']) {
            throw new Exception('Yetersiz bakiye');
        }

        // Yeni hayvanı ekle
        $stmt = $db->prepare("
            INSERT INTO user_animals (
                user_id, 
                animal_type_id, 
                health,
                energy,
                weight,
                price,
                last_fed,
                created_at
            ) VALUES (?, ?, 100, 100, ?, ?, NOW(), NOW())
        ");

        $stmt->execute([
            $userId,
            $animalTypeId,
            $animalType['initial_weight'],
            $animalType['initial_price']
        ]);

        // Kullanıcı bakiyesini güncelle
        $stmt = $db->prepare("
            UPDATE users 
            SET balance = balance - ? 
            WHERE id = ?
        ");
        $stmt->execute([$animalType['initial_price'], $userId]);

        // İşlem kaydı ekle
        $stmt = $db->prepare("
            INSERT INTO balance_transactions (
                user_id,
                type,
                amount,
                description,
                created_at
            ) VALUES (?, 'purchase', ?, ?, NOW())
        ");
        $stmt->execute([
            $userId,
            $animalType['initial_price'],
            $animalType['name'] . ' satın alındı'
        ]);

        // İşlemi onayla
        $db->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Hayvan başarıyla satın alındı',
            'new_balance' => $userBalance - $animalType['initial_price']
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }

} catch (Exception $e) {
    error_log("Buy animal error: " . $e->getMessage());
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 