<?php
require_once '../config.php';
require_once '../functions.php';
require_once '../auth.php';

header('Content-Type: application/json');

session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Oturum açmanız gerekiyor!'
    ]);
    exit();
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $notificationId = intval($input['id']);
    
    // Bildirimi okundu olarak işaretle
    $stmt = $db->prepare("
        UPDATE notifications 
        SET is_read = 1 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$notificationId, $_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Bildirim okundu olarak işaretlendi'
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 