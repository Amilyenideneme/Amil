<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../functions.php';

header('Content-Type: application/json');

try {
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Oturum açmanız gerekiyor');
    }

    $animalId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($animalId <= 0) {
        throw new Exception('Geçersiz hayvan ID');
    }

    $stmt = $db->prepare("
        SELECT 
            ua.*,
            at.feeding_cost,
            TIMESTAMPDIFF(MINUTE, ua.last_fed, NOW()) as minutes_since_fed
        FROM user_animals ua 
        JOIN animal_types at ON ua.animal_type_id = at.id
        WHERE ua.id = ? AND ua.user_id = ?
    ");
    $stmt->execute([$animalId, $_SESSION['user_id']]);
    $animal = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$animal) {
        throw new Exception('Hayvan bulunamadı');
    }

    echo json_encode([
        'success' => true,
        'animal' => $animal
    ]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 