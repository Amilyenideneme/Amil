<?php
session_start();
header('Content-Type: application/json');

require_once '../config.php';
require_once '../functions.php';

try {
    // Önceki çıktıları temizle
    while (ob_get_level()) ob_end_clean();
    
    // Oturum kontrolü
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('Oturum açmanız gerekiyor');
    }

    // Hayvan ID kontrolü
    $animalId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($animalId <= 0) {
        throw new Exception('Geçersiz hayvan ID');
    }

    // Veritabanı sorgusu
    $stmt = $db->prepare("
        SELECT 
            ua.*,
            at.name as animal_type,
            at.feeding_cost,
            TIMESTAMPDIFF(MINUTE, ua.last_fed, NOW()) as minutes_since_fed
        FROM user_animals ua 
        JOIN animal_types at ON ua.animal_type_id = at.id 
        WHERE ua.id = ? AND ua.user_id = ?
    ");
    
    $stmt->execute([$animalId, $_SESSION['user_id']]);
    $animal = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$animal) {
        throw new Exception('Hayvan bulunamadı');
    }

    // Beslenme durumunu hesapla
    $feedingInterval = getSetting('feeding_interval', 60); // dakika
    $remainingMinutes = max(0, $feedingInterval - $animal['minutes_since_fed']);
    
    $animal['feeding_status'] = $remainingMinutes <= 0 ? 'Beslenebilir' : $remainingMinutes . ' dakika kaldı';
    $animal['next_feeding'] = $remainingMinutes > 0 ? 'Bir sonraki beslenme: ' . $remainingMinutes . ' dakika sonra' : '';

    echo json_encode([
        'success' => true,
        'animal' => $animal
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 