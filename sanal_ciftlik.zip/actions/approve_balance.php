<?php
// Önceki çıktıları temizle
if (ob_get_level()) ob_end_clean();

// JSON header'ı ayarla
header('Content-Type: application/json; charset=utf-8');

try {
    require_once __DIR__ . '/../config.php';
    require_once __DIR__ . '/../functions.php';
    require_once __DIR__ . '/../auth.php';

    // Admin kontrolü
    checkAdmin();

    // POST verilerini al
    $transactionId = $_POST['transaction_id'] ?? 0;
    
    // Veritabanı işlemlerini başlat
    $db->beginTransaction();

    try {
        // İşlem bilgilerini al
        $stmt = $db->prepare("
            SELECT pbt.*, u.referred_by 
            FROM pending_balance_transactions pbt
            JOIN users u ON pbt.user_id = u.id
            WHERE pbt.id = ? AND pbt.status = 'pending'
            FOR UPDATE
        ");
        $stmt->execute([$transactionId]);
        $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$transaction) {
            throw new Exception('Geçersiz işlem!');
        }

        // Kullanıcı bakiyesini güncelle
        $stmt = $db->prepare("
            UPDATE users 
            SET balance = balance + ? 
            WHERE id = ?
        ");
        $stmt->execute([$transaction['amount'], $transaction['user_id']]);

        // İşlem kaydı ekle
        $stmt = $db->prepare("
            INSERT INTO balance_transactions (
                user_id, 
                type, 
                amount, 
                description, 
                created_at
            ) VALUES (?, 'deposit', ?, 'Bakiye yükleme', NOW())
        ");
        $stmt->execute([$transaction['user_id'], $transaction['amount']]);

        // Referans bonusu hesapla ve ekle
        if ($transaction['referred_by']) {
            $bonusPercentage = floatval(getSetting('referral_bonus_percentage', 5));
            $bonusAmount = ($transaction['amount'] * $bonusPercentage) / 100;

            if ($bonusAmount > 0) {
                // Referans eden kullanıcıya bonus ekle
                $stmt = $db->prepare("
                    UPDATE users 
                    SET balance = balance + ? 
                    WHERE id = ?
                ");
                $stmt->execute([$bonusAmount, $transaction['referred_by']]);

                // Referans bonus işlem kaydı
                $stmt = $db->prepare("
                    INSERT INTO balance_transactions (
                        user_id, 
                        type, 
                        amount, 
                        description, 
                        created_at
                    ) VALUES (?, 'referral_bonus', ?, ?, NOW())
                ");
                $stmt->execute([
                    $transaction['referred_by'], 
                    $bonusAmount, 
                    'Referans bonusu - ' . $transaction['user_id'] . ' numaralı kullanıcının ' . 
                    formatMoney($transaction['amount']) . ' bakiye yüklemesinden'
                ]);

                // Referans kazanç tablosuna ekle
                $stmt = $db->prepare("
                    INSERT INTO referral_earnings (
                        user_id,
                        referred_user_id,
                        amount,
                        transaction_amount,
                        percentage,
                        created_at
                    ) VALUES (?, ?, ?, ?, ?, NOW())
                ");
                $stmt->execute([
                    $transaction['referred_by'],
                    $transaction['user_id'],
                    $bonusAmount,
                    $transaction['amount'],
                    $bonusPercentage
                ]);

                // Bildirim gönder
                addNotification(
                    $transaction['referred_by'],
                    'Referans Bonusu',
                    'Referansınız ' . formatMoney($transaction['amount']) . 
                    ' bakiye yükledi. %' . $bonusPercentage . ' bonus olarak ' . 
                    formatMoney($bonusAmount) . ' kazandınız!',
                    'success'
                );
            }
        }

        // İşlem durumunu güncelle
        $stmt = $db->prepare("
            UPDATE pending_balance_transactions 
            SET status = 'approved', 
                processed_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$transactionId]);

        // Bildirim gönder
        addNotification(
            $transaction['user_id'],
            'Bakiye Yükleme Onaylandı',
            formatMoney($transaction['amount']) . ' tutarındaki bakiye yükleme talebiniz onaylanmıştır.',
            'success'
        );

        $db->commit();

        echo json_encode([
            'success' => true,
            'message' => 'İşlem başarıyla onaylandı'
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 