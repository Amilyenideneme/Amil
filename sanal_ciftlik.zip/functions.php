<?php
if (count(get_included_files()) == 1) {
    die('Bu dosyaya doğrudan erişim yasaktır.');
}

// Güvenlik kontrolü
if (!defined('DB_HOST')) {
    die('Doğrudan erişim engellendi.');
}

/**
 * Hayvan Yönetimi Fonksiyonları
 */

// Hayvan satın alma işlemi
function buyAnimal($userId, $animalTypeId) {
    global $db;
    
    try {
        $db->beginTransaction();
        
        // Hayvan türü bilgilerini al
        $stmt = $db->prepare("SELECT * FROM animal_types WHERE id = ?");
        $stmt->execute([$animalTypeId]);
        $animalType = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$animalType) {
            throw new Exception("Geçersiz hayvan türü!");
        }
        
        // Kullanıcı bakiyesini kontrol et
        $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $userBalance = $stmt->fetchColumn();
        
        if ($userBalance < $animalType['initial_price']) {
            throw new Exception("Yetersiz bakiye!");
        }
        
        // Bakiyeyi güncelle
        $stmt = $db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$animalType['initial_price'], $userId]);
        
        // Yeni hayvanı ekle
        $stmt = $db->prepare("
            INSERT INTO user_animals 
            (user_id, animal_type_id, age, weight, health, energy, feeding_status, price) 
            VALUES (?, ?, 0, ?, 100, 100, 100, ?)
        ");
        $stmt->execute([
            $userId,
            $animalTypeId,
            $animalType['initial_weight'],
            $animalType['initial_price']
        ]);
        
        $db->commit();
        return true;
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// Hayvan besleme işlemi
function feedAnimal($userId, $animalId) {
    global $db;
    
    try {
        $db->beginTransaction();
        
        // Hayvanın mevcut durumunu kontrol et
        $stmt = $db->prepare("
            SELECT ua.*, at.feeding_cost, 
            TIMESTAMPDIFF(MINUTE, ua.last_fed, NOW()) as minutes_since_fed
            FROM user_animals ua 
            JOIN animal_types at ON ua.animal_type_id = at.id 
            WHERE ua.id = ? AND ua.user_id = ?
        ");
        $stmt->execute([$animalId, $userId]);
        $animal = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$animal) {
            throw new Exception("Hayvan bulunamadı!");
        }
        
        // Son besleme zamanını kontrol et (60 dakika)
        if ($animal['minutes_since_fed'] < 60) {
            throw new Exception("Bu hayvan henüz beslenemez! " . (60 - $animal['minutes_since_fed']) . " dakika daha beklemelisiniz.");
        }
        
        // Kullanıcı bakiyesini kontrol et
        $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $userBalance = $stmt->fetchColumn();
        
        if ($userBalance < $animal['feeding_cost']) {
            throw new Exception("Yetersiz bakiye! Gerekli bakiye: " . formatMoney($animal['feeding_cost']));
        }
        
        // Bakiyeyi güncelle
        $stmt = $db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
        $stmt->execute([$animal['feeding_cost'], $userId]);
        
        // Hayvanı güncelle
        $stmt = $db->prepare("
            UPDATE user_animals 
            SET energy = LEAST(100, energy + 30),
                health = CASE 
                    WHEN health < 80 THEN LEAST(100, health + 10)
                    ELSE health
                END,
                feeding_status = LEAST(100, feeding_status + 25),
                last_fed = NOW()
            WHERE id = ? AND user_id = ?
        ");
        $stmt->execute([$animalId, $userId]);
        
        // Aktiviteyi logla
        logActivity($userId, 'feed_animal', "Hayvan #$animalId beslendi");
        
        $db->commit();
        return true;
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// Hayvan satış işlemi
function sellAnimal($userId, $animalId) {
    global $db;
    
    try {
        $db->beginTransaction();
        
        // Hayvanın durumunu kontrol et
        $stmt = $db->prepare("
            SELECT ua.*, at.selling_age, at.profit_percentage
            FROM user_animals ua 
            JOIN animal_types at ON ua.animal_type_id = at.id 
            WHERE ua.id = ? AND ua.user_id = ?
        ");
        $stmt->execute([$animalId, $userId]);
        $animal = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$animal) {
            throw new Exception("Hayvan bulunamadı!");
        }
        
        if ($animal['age'] < $animal['selling_age']) {
            throw new Exception("Bu hayvan henüz satış yaşına gelmedi!");
        }
        
        // Satış fiyatını hesapla
        $sellingPrice = calculateSellingPrice($animal);
        
        // Kullanıcı bakiyesini güncelle
        $stmt = $db->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$sellingPrice, $userId]);
        
        // Hayvanı sil
        $stmt = $db->prepare("DELETE FROM user_animals WHERE id = ?");
        $stmt->execute([$animalId]);
        
        $db->commit();
        return $sellingPrice;
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Yardımcı Fonksiyonlar
 */

// Satış fiyatı hesaplama
function calculateSellingPrice($animal) {
    $basePrice = $animal['price'];
    $healthMultiplier = $animal['health'] / 100;
    $weightMultiplier = $animal['weight'] / $animal['initial_weight'];
    $profitMultiplier = (100 + $animal['profit_percentage']) / 100;
    
    return round($basePrice * $healthMultiplier * $weightMultiplier * $profitMultiplier, 2);
}

// Güvenli input temizleme
function cleanInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Para formatı
function formatMoney($amount) {
    // Null veya boş değer kontrolü
    if ($amount === null || $amount === '') {
        $amount = 0;
    }
    
    // Sayısal değere çevir
    $amount = floatval($amount);
    
    // Türk Lirası formatında göster
    return number_format($amount, 2, ',', '.') . ' TL';
}

// Zaman formatı
function formatTime($timestamp) {
    return date('d.m.Y H:i:s', strtotime($timestamp));
}

// Hayvan yaşı hesaplama
function calculateAnimalAge($createdAt) {
    $diff = time() - strtotime($createdAt);
    return floor($diff / (60 * 60 * 24)); // Gün cinsinden yaş
}

// Hayvan durumu kontrolü
function checkAnimalStatus($animal) {
    if ($animal['health'] <= 0) {
        return 'Ölü';
    } elseif ($animal['health'] < 30) {
        return 'Çok Hasta';
    } elseif ($animal['health'] < 60) {
        return 'Hasta';
    } elseif ($animal['health'] < 90) {
        return 'İyi';
    } else {
        return 'Mükemmel';
    }
}

/**
 * Cron Job Fonksiyonları
 */

// Hayvanları güncelle
function updateAnimals() {
    global $db;
    
    try {
        $db->beginTransaction();
        
        // Tüm aktif hayvanları al
        $stmt = $db->prepare("
            SELECT ua.*, at.growth_rate,
            TIMESTAMPDIFF(MINUTE, ua.last_fed, NOW()) as minutes_since_fed
            FROM user_animals ua 
            JOIN animal_types at ON ua.animal_type_id = at.id 
            WHERE ua.health > 0
        ");
        $stmt->execute();
        $animals = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($animals as $animal) {
            // Beslenme durumuna göre sağlık ve enerji düşüşü hesapla
            $minutesSinceFed = $animal['minutes_since_fed'];
            
            // Her saat başı düşüşler
            $healthDecrease = 0;
            $energyDecrease = 0;
            
            // 1 saatten fazla beslenmemişse
            if ($minutesSinceFed > 60) {
                $hours = floor($minutesSinceFed / 60);
                $energyDecrease = min(5 * $hours, 20); // Saatte max 5 enerji düşüşü
                
                if ($animal['energy'] < 30) {
                    $healthDecrease = min(2 * $hours, 10); // Enerji düşükse saatte max 2 sağlık düşüşü
                }
            }
            
            // Hayvanı güncelle
            $stmt = $db->prepare("
                UPDATE user_animals 
                SET health = GREATEST(0, health - ?),
                    energy = GREATEST(0, energy - ?),
                    feeding_status = GREATEST(0, feeding_status - ?),
                    weight = CASE 
                        WHEN energy >= 50 THEN weight + ?
                        ELSE weight
                    END,
                    age = age + ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $healthDecrease,
                $energyDecrease,
                1, // Beslenme durumu saatte 1 düşer
                ($animal['energy'] >= 50 ? $animal['growth_rate'] : 0), // Enerji 50'nin üstündeyse büyüme
                1/24, // Saatlik yaş artışı (gün cinsinden)
                $animal['id']
            ]);
        }
        
        $db->commit();
        return true;
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

// Ölü hayvanları temizle
function cleanDeadAnimals() {
    global $db;
    
    $stmt = $db->prepare("DELETE FROM user_animals WHERE health <= 0");
    return $stmt->execute();
}

/**
 * Kullanıcı bakiyesini getiren fonksiyon
 * @param int|null $userId
 * @return float
 */
function getUserBalance($userId = null) {
    global $db;
    
    // Kullanıcı ID kontrolü
    if (!$userId && isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
    }
    
    if (!$userId) {
        return 0;
    }
    
    try {
        $stmt = $db->prepare("SELECT balance FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        return $stmt->fetchColumn() ?: 0;
    } catch (Exception $e) {
        error_log("Bakiye getirme hatası: " . $e->getMessage());
        return 0;
    }
}

function getAnimalIcon($animalType) {
    $icons = [
        'Cow' => 'fa-cow',
        'Chicken' => 'fa-kiwi-bird',
        'Sheep' => 'fa-sheep',
        'Pig' => 'fa-pig',
        'default' => 'fa-paw'
    ];
    
    $type = ucfirst(strtolower($animalType));
    return isset($icons[$type]) ? $icons[$type] : $icons['default'];
}

function getHealthColor($health) {
    if ($health >= 75) return 'success';
    if ($health >= 50) return 'warning';
    if ($health >= 25) return 'info';
    return 'danger';
}

function getEnergyColor($energy) {
    if ($energy >= 75) return 'success';
    if ($energy >= 50) return 'warning';
    if ($energy >= 25) return 'primary';
    return 'danger';
}

/**
 * Site ayarlarını getiren fonksiyon
 */
function getSettings() {
    global $db;
    
    try {
        // Önce cache'i kontrol et
        static $settings = null;
        
        if ($settings === null) {
            $stmt = $db->query("SELECT setting_key, value FROM settings");
            $settings = [];
            
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $settings[$row['setting_key']] = $row['value'];
            }
            
            // Varsayılan değerleri ayarla
            $defaults = [
                'site_name' => 'Sanal Çiftlik',
                'site_description' => 'Online Çiftlik Yönetim Oyunu',
                'maintenance_mode' => '0',
                'min_deposit' => '10',
                'max_deposit' => '1000',
                'min_withdrawal' => '50',
                'max_withdrawal' => '5000',
                'daily_bonus' => '5',
                'referral_bonus' => '10',
                'growth_multiplier' => '1',
                'feed_cost_multiplier' => '1',
                'profit_multiplier' => '1',
                'market_fee' => '5',
                'min_market_price' => '1',
                'max_market_price' => '100000'
            ];
            
            // Eksik ayarları varsayılan değerlerle doldur
            foreach ($defaults as $key => $value) {
                if (!isset($settings[$key])) {
                    $settings[$key] = $value;
                }
            }
        }
        
        return $settings;
    } catch (Exception $e) {
        error_log("Ayarları getirme hatası: " . $e->getMessage());
        return [];
    }
}

/**
 * Belirli bir ayarı getiren fonksiyon
 */
function getSetting($key, $default = null) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT value FROM settings WHERE name = ?");
        $stmt->execute([$key]);
        $value = $stmt->fetchColumn();
        
        return $value !== false ? $value : $default;
    } catch (Exception $e) {
        error_log("Ayar getirme hatası: " . $e->getMessage());
        return $default;
    }
}

/**
 * Ayarları güncelleyen fonksiyon
 */
function updateSetting($key, $value) {
    global $db;
    
    try {
        $stmt = $db->prepare("
            INSERT INTO settings (setting_key, value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE value = ?
        ");
        
        return $stmt->execute([$key, $value, $value]);
    } catch (Exception $e) {
        error_log("Ayar güncelleme hatası: " . $e->getMessage());
        return false;
    }
}

/**
 * Kullanıcı aktivitelerini loglayan fonksiyon
 * @param int $userId
 * @param string $action
 * @param string|null $details
 * @return bool
 */
function logActivity($userId, $action, $details = null) {
    global $db;
    
    try {
        $stmt = $db->prepare("
            INSERT INTO activity_logs (user_id, action, details) 
            VALUES (?, ?, ?)
        ");
        
        return $stmt->execute([
            $userId,
            $action,
            $details
        ]);
    } catch (Exception $e) {
        error_log("Aktivite log hatası: " . $e->getMessage());
        return false;
    }
}

function getHealthStatus($health) {
    if ($health <= 20) {
        return 'Kritik Durum';
    } elseif ($health <= 40) {
        return 'Kötü';
    } elseif ($health <= 60) {
        return 'Hasta';
    } elseif ($health <= 80) {
        return 'İyi';
    } else {
        return 'Mükemmel';
    }
}