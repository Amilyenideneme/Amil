<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'auth.php';

// Oturum kontrolü
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Tüm bildirimleri okundu olarak işaretle
if (isset($_GET['mark_all_read'])) {
    $stmt = $db->prepare("
        UPDATE notifications 
        SET is_read = 1 
        WHERE user_id = ? AND is_read = 0
    ");
    $stmt->execute([$_SESSION['user_id']]);
    header('Location: notifications.php');
    exit();
}

// Bildirimleri getir
$stmt = $db->prepare("
    SELECT * FROM notifications 
    WHERE user_id = ? 
    ORDER BY created_at DESC
    LIMIT 50
");
$stmt->execute([$_SESSION['user_id']]);
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Header'ı dahil et
$pageTitle = "Bildirimlerim";
include 'templates/header.php';
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h2 class="mb-0">Bildirimlerim</h2>
                    <?php if (!empty($notifications)): ?>
                        <div class="btn-group">
                            <a href="?mark_all_read=1" class="btn btn-sm btn-secondary">
                                <i class="fas fa-check-double"></i> Tümünü Okundu İşaretle
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if (empty($notifications)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                            <h4>Henüz Bildiriminiz Yok</h4>
                            <p class="text-muted">Yeni bildirimleriniz burada görüntülenecektir.</p>
                        </div>
                    <?php else: ?>
                        <div class="notifications-list">
                            <?php foreach ($notifications as $notification): ?>
                                <div class="notification-item <?php echo !$notification['is_read'] ? 'unread' : ''; ?>"
                                     data-id="<?php echo $notification['id']; ?>"
                                     onclick="markAsRead(<?php echo $notification['id']; ?>)">
                                    <div class="notification-icon">
                                        <i class="fas fa-circle text-<?php echo $notification['type']; ?>"></i>
                                    </div>
                                    <div class="notification-content">
                                        <div class="notification-title">
                                            <?php echo htmlspecialchars($notification['title']); ?>
                                        </div>
                                        <div class="notification-message">
                                            <?php echo htmlspecialchars($notification['message']); ?>
                                        </div>
                                        <div class="notification-time">
                                            <?php echo formatTime($notification['created_at']); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.notifications-list {
    max-height: 600px;
    overflow-y: auto;
}

.notification-item {
    display: flex;
    padding: 15px;
    border-bottom: 1px solid #eee;
    cursor: pointer;
    transition: background-color 0.2s;
}

.notification-item:hover {
    background-color: #f8f9fa;
}

.notification-item.unread {
    background-color: #f0f8ff;
}

.notification-icon {
    flex: 0 0 30px;
    display: flex;
    align-items: flex-start;
    padding-top: 3px;
}

.notification-content {
    flex: 1;
}

.notification-title {
    font-weight: bold;
    margin-bottom: 5px;
}

.notification-message {
    color: #666;
    margin-bottom: 5px;
}

.notification-time {
    font-size: 0.8em;
    color: #999;
}

.card-header .btn-group {
    margin-left: 10px;
}

.card-header .btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}
</style>

<?php include 'templates/footer.php'; ?> 